#--START TRANSACTION;

USE cbourke;

DROP TABLE IF EXISTS enrollment;
DROP TABLE IF EXISTS course;
DROP TABLE IF EXISTS email;
DROP TABLE IF EXISTS student;

#--INDEX and KEY are the same in MySQL

CREATE TABLE student (
       student_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
       nuid       VARCHAR(8)  NOT NULL,
       first_name VARCHAR(50) NOT NULL,
       last_name  VARCHAR(50) NOT NULL,
       CONSTRAINT unique_key_nuid UNIQUE INDEX(nuid),
       CONSTRAINT check_non_empty CHECK (LENGTH(first_name) > 0)
)Engine=InnoDB,COLLATE=latin1_general_cs;

INSERT INTO student (nuid, first_name, last_name) VALUES
                    ('35140602', 'Chris', 'Bourke');
#--fails unique_key_nuid constraint!
#--should we have included first and last name?
#--INSERT INTO student (nuid, first_name, last_name) VALUES
#--                    ('35140602', 'Joe', 'Bourke');
#-- without UNIQUE, its just an ordinary index for database
INSERT INTO student (nuid, first_name, last_name) VALUES
                    ('00112233', 'John', 'Student');

#--should fail, but CHECK constraints are ignored in MySQL:
#--INSERT INTO Student (nuid, first_name, last_name) VALUES
#--                    ('11223344', '', 'Student');

CREATE TABLE email (
       email_id INT NOT NULL AUTO_INCREMENT,
       student_id INT NOT NULL,
       address VARCHAR(100) NOT NULL,
       PRIMARY KEY(email_id),
       FOREIGN KEY(student_id) REFERENCES student(student_id)
)Engine=InnoDB,COLLATE=latin1_general_cs;

#--How can we insert email when we don't have a foreign key?
#--Use a subquery!
INSERT INTO email(student_id, address) VALUES ((SELECT student_id FROM student WHERE nuid = '35140602'), 'cbourke@cse.unl.edu');

#--fails because there is no student_id = 100
#--INSERT INTO email(student_id, address) VALUES (100, 'cbourke@cse.unl.edu');

CREATE TABLE course (
       course_id INT NOT NULL AUTO_INCREMENT,
       name      VARCHAR(15) NOT NULL,
       description VARCHAR(2048) NOT NULL DEFAULT '',
       PRIMARY KEY(course_id)
)Engine=InnoDB,COLLATE=latin1_general_cs;

INSERT INTO course (name, description) VALUES ('CSCE 155A', 'Introduction to Computer Science I');
INSERT INTO course (name, description) VALUES ('CSCE 156', 'Introduction to Computer Science II');
INSERT INTO course (name, description) VALUES ('CSCE 235', 'Discrete Mathematics');

CREATE TABLE enrollment (
       enrollment_id INT NOT NULL AUTO_INCREMENT,
       student_id INT NOT NULL,
       course_id INT NOT NULL,
       semester VARCHAR(10) NOT NULL,
       PRIMARY KEY(enrollment_id),
       KEY(student_id,course_id,semester),
       FOREIGN KEY(student_id) REFERENCES student(student_id),
       FOREIGN KEY(course_id) REFERENCES course(course_id)
)Engine=InnoDB,COLLATE=latin1_general_cs;

INSERT INTO enrollment (student_id, course_id, semester) VALUES ((SELECT student_id FROM student WHERE nuid = '35140602'), 
                                                                 (SELECT course_id FROM course where name = 'CSCE 156'), 
								 'Fall 2011');

#--Could normalize further with a Semester table?

#--COMMIT;

