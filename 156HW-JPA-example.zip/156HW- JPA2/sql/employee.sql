USE cbourke;

DROP TABLE IF EXISTS employeeEmail;
DROP TABLE IF EXISTS employee;

CREATE TABLE employee (
  employee_id INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
  first_name  VARCHAR(255) NOT NULL,
  last_name   VARCHAR(255) NOT NULL,
  employee_type VARCHAR(255) NOT NULL,
  salary_employee_title VARCHAR(255),
  hourly_employee_class VARCHAR(255),
  base_pay    FLOAT NOT NULL DEFAULT 0.0 
)Engine=InnoDB,COLLATE=latin1_general_cs;

CREATE TABLE employeeEmail (
  employee_email_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
  employee_id INT NOT NULL,
  address VARCHAR(100) NOT NULL,
  FOREIGN KEY `fk_email_to_employee` (employee_id) REFERENCES employee(employee_id)
) ENGINE=INNODB,COLLATE=latin1_general_cs;

INSERT INTO employee (employee_id, first_name, last_name, employee_type, salary_employee_title, base_pay) VALUES (1, 'George', 'Bailey', 'S', 'Manager', 10000.00);
INSERT INTO employee (employee_id, first_name, last_name, employee_type, salary_employee_title, base_pay) VALUES (2, 'Henry', 'Potter', 'S', 'Scrum Master', 150000.00);
INSERT INTO employee (employee_id, first_name, last_name, employee_type, hourly_employee_class, base_pay) VALUES (3, 'Mary', 'Hatch', 'H', 'TEMP00A', 8000.00);
INSERT INTO employee (employee_id, first_name, last_name, employee_type, hourly_employee_class, base_pay) VALUES (4, 'Billy', 'Bailey', 'H', 'CONS00B', 4000.00);

INSERT INTO employeeEmail (employee_id,address) VALUES (1, 'gbailey@gmail.com');
INSERT INTO employeeEmail (employee_id,address) VALUES (1, 'george@bbl.com');
INSERT INTO employeeEmail (employee_id,address) VALUES (1, 'g_bailey@bedfordhigh.edu');
INSERT INTO employeeEmail (employee_id,address) VALUES (2, 'h.potter@email.com');
INSERT INTO employeeEmail (employee_id,address) VALUES (2, 'hpotter@gmail.com');
INSERT INTO employeeEmail (employee_id,address) VALUES (3, 'mhatch@yahoo.com');

