package unl.cse.jpa;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPADemo {

	//Hibernate download: http://www.hibernate.org/downloads.html
	
	public static void main(String args[]) {

		EntityManagerFactory emf = null; 
		EntityManager em = null;
		List<StudentEntity> se = null;
		
		try {
			emf = Persistence.createEntityManagerFactory("cbourke_database");
			em = emf.createEntityManager();

			em.getTransaction().begin();
			//Other usage:
			//em.persist(...);
			//em.detach(...);
			//em.flush(); -synchs up EM with database
			//em.merge(...);
			//em.remove(...);
			String query = "FROM StudentEntity";
			
			try {
				
				se = (List<StudentEntity>) em.createQuery(query).getResultList();
				 
				//parameterized alternative: 
				//em.find(StudentEntity.class, 1);
				StudentEntity s = se.get(0);
				 
				 EmailEntity email = new EmailEntity();
				 email.setStudent(s);
				 email.setAddress("ournewemailaddress@unl.edu");
				 em.persist(email);
				 em.refresh(s);
				 
			} catch(Exception e) {
				System.out.println("Error loading StudentEntity");
				e.printStackTrace();
				if (em.getTransaction().isActive()) {
					em.getTransaction().rollback();
				}
				throw new RuntimeException("Error loading StudentEntity", e);
			}

			//em.getTransaction().commit();
			em.getTransaction().rollback();
			
		} catch (Exception e) {
			e.printStackTrace();
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
		} finally {
			if (em != null && em.isOpen()) {
				em.close();
			}
			if (emf != null && emf.isOpen()) {
				emf.close();
			}

		}

		//Entity is detached at this point

		for(StudentEntity s : se) {
			System.out.println("StudentEntity: "+s);
			System.out.println("My courses: ");
			for(CourseEntity ce : s.getCourses()) {
				System.out.println("\t" + ce);
			}
		}
		

	}

	
}
