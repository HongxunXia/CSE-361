package unl.cse.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="email")
public class EmailEntity implements Serializable {

	private static final long serialVersionUID = 6127181618700653959L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="email_id", nullable=false)
	private Integer id;
	
	@Column(name="address", nullable=false)
	private String address;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="student_id", nullable=false)
	private StudentEntity student;

	public EmailEntity() {}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	@Override 
	public String toString() {
		return this.address;
	}

	public StudentEntity getStudent() {
		return student;
	}

	public void setStudent(StudentEntity student) {
		this.student = student;
	}


}
