package unl.cse.JPA2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;

@SuppressWarnings("unused")
public class PortfolioReportList {
	public static void main(String[] args) {


		Comparator<Portfolio> byName= new Comparator<Portfolio>(){

			public int compare(Portfolio one, Portfolio other) {
				if (one.getOwner().getLastName().equals(other.getOwner().getLastName())){
					return one.getOwner().getFirstName().compareTo(other.getOwner().getFirstName());
				}
				else{
					return one.getOwner().getLastName().compareTo(other.getOwner().getLastName());
				}

			}
		};


		Comparator<Portfolio> byValue= new Comparator<Portfolio>(){
			public int compare(Portfolio one, Portfolio other) {
				if (one.getTotalValue()-other.getTotalValue()<0){
					return 1;
				}
				else if (one.getTotalValue()-other.getTotalValue()>0){
					return -1;
				}
				else{
					return 0;
				}

			}
		};


		Comparator<Portfolio> byManager= new Comparator<Portfolio>(){
			public int compare(Portfolio one, Portfolio other) {
				if (one.getManager().getType().equals(other.getManager().getType())){
					if (one.getManager().getLastName().equals(other.getManager().getLastName())){
						return one.getManager().getFirstName().compareTo(other.getManager().getFirstName());
					}
					else{
						return one.getManager().getLastName().compareTo(other.getManager().getLastName());
					}
				}
				else if (one.getManager().getType().equals("E")){
					return -1;
				}
				else{
					return 1;
				}

			}
		};



		MySortedList<Portfolio> listByName=new MySortedList<Portfolio>(byName);

		MySortedList<Portfolio> listByValueHighToLow=new MySortedList<Portfolio>(byValue);


		MySortedList<Portfolio> listByManager=new MySortedList<Portfolio>(byManager);

		//BasicConfigurator.configure();
		//ArrayList<Portfolio> portfolioList= Portfolio.portfolioParser();//this gives an arraylist of portfolios reading from the file portfolio.dat
		//ArrayList<Portfolio> portfolioList = PortfolioBean.getAllPortfolio();//this gives an arraylist of portfolios reading from database
	
		
		
		ArrayList<Portfolio> portfolioList = CopyOfPortfolioBean.getAllPortfolio();
		
		
		
		System.out.println("Orderd by Name");		
		listByName.addAll(portfolioList);
		Portfolio.summary( listByName);
		System.out.println("Orderd by value");	
		listByValueHighToLow.addAll(portfolioList);
		Portfolio.summary( listByValueHighToLow);
		listByManager.addAll(portfolioList);
		System.out.println("Orderd by Manager");	
		Portfolio.summary( listByManager);












		//Portfolio.summary(portfolioList);//shows a summary of portfolios
		//Portfolio.detailsAll(portfolioList);//shows every portfolio's detailed info
	}//end main






}//end class
