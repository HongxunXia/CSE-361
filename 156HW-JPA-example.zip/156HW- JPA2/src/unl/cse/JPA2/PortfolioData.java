package unl.cse.JPA2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;

/**
 * This is a collection of utility methods that define a general API for
 * interacting with the database supporting this application.
 *
 */
@SuppressWarnings("unused")
public class PortfolioData {
	
	private static Logger log = Logger.getLogger(PortfolioData.class);
	
	public static void main(String[] args) {
		BasicConfigurator.configure();
		//===== test code (commented out) =========================================================================
		//addPerson("EEEf", "Bin222", "Chen444", "99991 O ST", "Lincoln", "KK", "68508", "USA333", "E", "sec444") ;
		//addState("KK");
		//System.out.println(addState("KK"));	
		//System.out.println(addCountry("USAddd"));
		//removeAsset("BUBBAG");
		//removeAllAssets() ;
		//addDepositAccount("CD999", "99999", 0.99);
		//removeAsset("CD999");
		//addPrivateInvestment( "BIN99", "HAHA", 0.67, 0.45, 0.45, 999999.99);
		//addPrivateInvestment(String assetCode, String label, Double quarterlyDividend, 
		//Double baseRateOfReturn, Double omega, Double totalValue)
		//removePortfolio("PF010");
		//removeAllPortfolios();
		//System.out.println(PersonBean.getDetialedPersonByCode(null).name);
		//addPortfolio("PF887", "URAD", "URAD", null);
		//removePortfolio( "PF887");
		//removePerson("URAD");
		//removeEmailByID(2);
		//removeAddressByID(2);
		//removeAllPersons();
		//addAsset("PF010", "MONMO1", 999999.99);
		//addAsset("PF010", "RNT666", 99);
		//addAsset("PF010", "TABLET", 99);
		//addAsset("PF999", "TABLET", 99);
		//addAsset("PF010", "CCCC", 99);
		//==============================
		
		
	}

	/**
	 * Method that removes every person record from the database
	 */
	public static void removeAllPersons() {
		//find all personCode and use a while loop to call removePerson(String personCode) method
		Connection conn=ConnectionBean.getConnection();
		String query="SELECT personCode FROM Person ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			ps = conn.prepareStatement( query);
			rs=ps.executeQuery();
			while(rs.next()){
				removePerson(rs.getString("personCode"));	
			}
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		
		ConnectionBean.closeConnection(rs, ps, conn);
	}
	

	/**
	 * Removes the person record from the database corresponding to the
	 * provided <code>personCode</code>
	 * @param personCode
	 */
	public static void removePerson(String personCode) {
		//1) check if the person exist, if does not exist, do nothing, if exist get PersonID (by call getDetailedPersonbyCode() )
		Person p = PersonBean.getDetailedPersonByCode(personCode); 
		if(p==null){
			System.out.println("Person does not exist!");
			return;
		}
		//2) find its PersonID, AddressID, EmailID ,delete Address and Email
		int PersonID=p.PersonID;
		int AddressID=p.getAddress().getAddressID();
		removeAddressByID(AddressID);
		 	//note a person might have multiple emails, a person can only have one address by design
			//finding its EmailID(s) and remove them all
		
		Connection conn=ConnectionBean.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			ps = conn.prepareStatement( " SELECT e.EmailID,a.AddressID, personCode, lastName, firstName,secCode,type,street,city,state,country,zip,emailAddress "+ 
					" FROM Person p LEFT JOIN Email e ON p.PersonID=e.PersonID LEFT JOIN Address a ON p.PersonID=a.PersonID "+
					" LEFT JOIN State s ON s.StateID= a.StateID LEFT JOIN Country c ON c.CountryID=a.CountryID "+
					 " WHERE p.PersonID=? ");
			ps.setInt(1, PersonID);
			rs = ps.executeQuery();
			while(rs.next()){
				removeEmailByID(rs.getInt("EmailID"));
			}
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
				
		//3) Check if this person is a broker, ownner or beneficiary first
		     //if a Broker or binerficay, simply find the PortfolioID and set the brokerID/beneficiaryID to be null
		     // if it is a owner, then delete the portflio using removePortfolio(String portfolioCode), this method removes the portfolio and its associate assets and records in PortfolioAsset
		
		String query="SELECT p.personCode,p.lastName,p.firstName,p.PersonID,pf.PortfolioID,pf.portfolioCode,pf.OwnerID,pf.BrokerID,pf.BeneficiaryID FROM Person p"+
					"  JOIN Portfolio pf ON p.personID=pf.OwnerID OR p.personID=pf.BrokerID OR p.personID=pf.BeneficiaryID "+
					"  WHERE p.PersonID=? ";

		try {
			ps = conn.prepareStatement( query);
			ps.setInt(1, PersonID);
			rs = ps.executeQuery();
			
			while(rs.next()){
				int OwnerID=rs.getInt("OwnerID");
				int BrokerID=rs.getInt("BrokerID");
			    int BeneficiaryID=rs.getInt("BeneficiaryID");
			    String portfolioCode=rs.getString("portfolioCode");
			    int PortfolioID=rs.getInt("PortfolioID");
			    if(PersonID==OwnerID){//this person is a owner, delete his portfolio
					removePortfolio( portfolioCode);
					
				}else {
					if (PersonID==BrokerID){//this person is a Broker, set BrokerID to be null
						try {
							ps = conn.prepareStatement( "UPDATE`Portfolio` SET `BrokerID`=NULL WHERE `PortfolioID`=? ");
							ps.setInt(1, PortfolioID);
							ps.executeUpdate();
						} catch (SQLException e) {
							System.out.println("SQLException: ");
							e.printStackTrace();
							log.error("SQLException: ", e);
							throw new RuntimeException(e);
						}
					}
				   if (PersonID==BeneficiaryID){//this person is a Beneficiary, set BeneficiaryID to be null
						
						try {
							ps = conn.prepareStatement( "UPDATE`Portfolio` SET `BeneficiaryID`=NULL WHERE `PortfolioID`=? ");
							ps.setInt(1, PortfolioID);
							ps.executeUpdate();
						} catch (SQLException e) {
							System.out.println("SQLException: ");
							e.printStackTrace();
							log.error("SQLException: ", e);
							throw new RuntimeException(e);
						}
				   }

				}
				
			}//end while
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
					
		//4) lastly remove the person	
			try {
				ps = conn.prepareStatement( "DELETE FROM `Person` WHERE `PersonID`=? ");
				ps.setInt(1, PersonID);
				ps.executeUpdate();
			} catch (SQLException e) {
				System.out.println("SQLException: ");
				e.printStackTrace();
				log.error("SQLException: ", e);
				throw new RuntimeException(e);
			}

		ConnectionBean.closeConnection(rs, ps, conn);
	}//end method
	
	
	/**
	 * Method to add a person record to the database with the provided data. The
	 * <code>brokerType</code> will either be "E" or "J" (Expert or Junior) or 
	 * <code>null</code> if the person is not a broker.
	 * @param personCode
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param city
	 * @param state
	 * @param zip
	 * @param country
	 * @param brokerType
	 * @throws SQLException 
	 */
	public static void addPerson(String personCode, String firstName, String lastName, String street, String city, String state, String zip, String country, String brokerType, String secBrokerId)  {
		//make sure the person doesn't exist first...
		Person p=PersonBean.getDetailedPersonByCode(personCode);
		if (p !=null){// this person already exist
			return;
		}
		
		//otherwise this is a new person, adding info to database
		//1). Adding the state into State table (checking if state exist in the database, if yes then get its StateID, if not then create it, this is done in the addState() method)
		int StateID=addState(state);
			
		//2)  Adding the Country into Country table (checking if Country exist in the database, if yes then get its CountryID, if not then create it.this is done in the addCountry() method)
			int CountryID=	addCountry(country);
				  
	    //3) adding person and get PersonID	  
				  int PersonID=0;
			Connection conn=ConnectionBean.getConnection();
			PreparedStatement ps = null;
				
				String	query="INSERT INTO `Person` (`personCode`, `lastName`, firstName , `secCode`, `annualFee`, `commission`, `type`) VALUES (?, ?, ?, ?, ?, ?, ?)";
				try{
					
					ps = conn.prepareStatement(query);
					ps.setString(1, personCode);
					ps.setString(2, lastName);
					ps.setString(3, firstName);
					
					if ( brokerType== null){
						ps.setNull(4, java.sql.Types.VARCHAR);
						ps.setNull(5, java.sql.Types.DECIMAL);
						ps.setNull(6, java.sql.Types.DECIMAL);
						ps.setString(7, "C");
					}
					else if (brokerType.equals("E")){
						ps.setString(4, secBrokerId);
						ps.setDouble(5, 10);
						ps.setDouble(6, 0.05);
						ps.setString(7, "E");
					}
					else if (brokerType.equals("J")){
						ps.setString(4, secBrokerId);
						ps.setDouble(5, 50);
						ps.setDouble(6, 0.02);
						ps.setString(7, "J");
					} else {
						throw new IllegalStateException("Unrecognized brokerType "+Arrays.asList( personCode,  firstName,  lastName,  street,  city,  state,  zip, country, brokerType, secBrokerId));
					}
					
					ps.executeUpdate();
					
				}catch (SQLException e) {
					System.out.println("SQLException: " +Arrays.asList( personCode,  firstName,  lastName,  street,  city,  state,  zip, country, brokerType, secBrokerId));
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
				}
			
				//getting PersonID of the newly added person	
				ResultSet rs=null;
				query="SELECT PersonID, personCode FROM Person WHERE personCode=?";
				try{
					ps = conn.prepareStatement(query);
					ps.setString(1, personCode);
					rs = ps.executeQuery();
					if (rs.next()){
						PersonID=rs.getInt("PersonID");
					}
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
			}	

			//4) finally adding Address and associate it with the person
		  query="INSERT INTO `Address` (`street`, `city`, `zip`, `PersonID`, `StateID`, `CountryID`) VALUES (?, ?, ?, ?, ?, ?)";
			try{
				
				ps = conn.prepareStatement(query);
				ps.setString(1, street);
				ps.setString(2, city);
				ps.setString(3, zip);
				ps.setInt(4, PersonID);
				ps.setInt(5, StateID);
				ps.setInt(6, CountryID);
				
				ps.executeUpdate();
			}catch (SQLException e) {
				System.out.println("SQLException: ");
				e.printStackTrace();
				log.error("SQLException: ", e);
				throw new RuntimeException(e);
			}
			
			ConnectionBean.closeConnection(rs, ps, conn);
			
	}//end addPerson
	
	/**
	 * Adds an email record corresponding person record corresponding to the
	 * provided <code>personCode</code>
	 * @param personCode
	 * @param email
	 */
	public static void addEmail(String personCode, String email) {
		//check the person exist first...
				Person p=PersonBean.getDetailedPersonByCode(personCode);
				if (p !=null){// this person already exist
					//adding Email
					Connection conn=ConnectionBean.getConnection();
					String query="INSERT INTO `Email` (`emailAddress`, `PersonID`) VALUES ( ? , ? )";
					PreparedStatement ps=null;
					ResultSet rs=null;
					try {
						ps = conn.prepareStatement(query);
						ps.setString(1, email);
						ps.setInt(2, p.PersonID);
						ps.executeUpdate();
					} catch (SQLException e) {
						System.out.println("SQLException: ");
						e.printStackTrace();
						log.error("SQLException: ", e);
						throw new RuntimeException(e);
					}
					ConnectionBean.closeConnection(rs, ps, conn);
				}
				else {//person does not exist
					System.out.println("Adding email failed ,this person does not exist");
				}
	}

	
	/**
	 * Removes all asset records from the database
	 */
	public static void removeAllAssets() {
		
		Connection conn= ConnectionBean.getConnection();
		String query="SELECT assetCode FROM Asset GROUP BY assetCode";
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try{
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()){
				removeAsset(rs.getString("assetCode"));
			}
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);
	}
	
	/**
	 * Removes the asset record from the database corresponding to the
	 * provided <code>assetCode</code>
	 * @param assetCode
	 */
	public static void removeAsset(String assetCode) {
		
		//first to check if we have this asset in database
		Connection conn= ConnectionBean.getConnection();
		String query="SELECT AssetID FROM Asset WHERE assetCode= ? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, assetCode);
			rs = ps.executeQuery();
			if (!rs.next()){//asset does not exist in database, no need to do anything
				System.out.println("asset does not exist!");
				ConnectionBean.closeConnection(rs, ps, conn);
				return;
			}
			rs.close();
			} catch (SQLException e) {
				System.out.println("SQLException: ");
				e.printStackTrace();
				log.error("SQLException: ", e);
				throw new RuntimeException(e);
			}
		
		//the process of removing asset
		//need to clear the portfolioAsset and then the asset
				//as an all-or-nothing transaction
		// first remove record in portfolioAsset table that are associated with this asset.
		List<Integer> PortfolioAssetIDList= new ArrayList<Integer>();
		List<Integer> AssetIDList= new ArrayList<Integer>();		
		
		// get PortfolioAssetID that are associated with this asset.
		query="SELECT PortfolioAssetID FROM PortfolioAsset WHERE AssetID IN (SELECT AssetID FROM Asset WHERE assetCode= ? )";
		
		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, assetCode);
			rs = ps.executeQuery();
			while (rs.next()){
				//put PortfolioAssetID into an ArrayList
				PortfolioAssetIDList.add(rs.getInt("PortfolioAssetID"));
				
			}//end while
				
			rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		
		//get AssetID 
		query="SELECT AssetID FROM Asset WHERE assetCode= ? ";
		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, assetCode);
			rs = ps.executeQuery();
			while (rs.next()){
				AssetIDList.add(rs.getInt("AssetID"));
				
			}//end while
				
			rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		
		//removing record from PortfolioAsset and all asset
		try{
			conn.setAutoCommit(false);
			//removing PortfolioAsset
			query="DELETE FROM `PortfolioAsset` WHERE `PortfolioAssetID`= ? ";
			for (int i :PortfolioAssetIDList){
				ps = conn.prepareStatement(query);
				ps.setInt(1, i);
				ps.executeUpdate();
			}
			//removing all asset
			query="DELETE FROM Asset WHERE AssetID= ? ";
			for (int i :AssetIDList){
				ps = conn.prepareStatement(query);
				ps.setInt(1, i);
				ps.executeUpdate();
			}
				
			conn.commit();
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e2) {
				System.out.println("SQLException attempting to rollback: ");
				e2.printStackTrace();
			}
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		
		ConnectionBean.closeConnection(rs, ps, conn);
			
	}
	
	/**
	 * Adds a deposit account asset record to the database with the
	 * provided data. 
	 * @param assetCode
	 * @param label
	 * @param apr
	 */

	public static void addDepositAccount(String assetCode, String label, double apr) {
	
	Connection conn= ConnectionBean.getConnection();
	//check if the asset exist
	String query="SELECT AssetID FROM Asset WHERE assetCode=? ";
	PreparedStatement ps=null;
	ResultSet rs=null;
	try{
		ps = conn.prepareStatement(query);
		ps.setString(1, assetCode);
		rs = ps.executeQuery();
		if (rs.next()){//asset already exist
			System.out.println("Asset already exist!");
			ConnectionBean.closeConnection(rs, ps, conn);
			return;
		}
	} catch (SQLException e) {
		System.out.println("SQLException: ");
		e.printStackTrace();
		log.error("SQLException: ", e);
		throw new RuntimeException(e);
	}
	
	//asset does not exist, inserting
	 query="INSERT INTO  `Asset` (`assetCode`, `label`, `type`, `apr`) VALUES (?, ?, 'D', ? )";

	try{
		ps = conn.prepareStatement(query);
		ps.setString(1, assetCode);
		ps.setString(2, label);
		ps.setDouble(3, apr*100);
		ps.executeUpdate();
	} catch (SQLException e) {
		System.out.println("SQLException: ");
		e.printStackTrace();
		log.error("SQLException: ", e);
		throw new RuntimeException(e);
	}
	
	ConnectionBean.closeConnection(rs, ps, conn);
}

	/**
	 * Adds a private investment asset record to the database with the
	 * provided data. 
	 * @param assetCode
	 * @param label
	 * @param quarterlyDividend
	 * @param baseRateOfReturn
	 * @param omega
	 * @param totalValue
	 */

	public static void addPrivateInvestment(String assetCode, String label, Double quarterlyDividend, 
			Double baseRateOfReturn, Double omega, Double totalValue) {
		Connection conn= ConnectionBean.getConnection();
		//check if the asset exist
		String query="SELECT AssetID FROM Asset WHERE assetCode=? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, assetCode);
			rs = ps.executeQuery();
			if (rs.next()){//asset already exist
				System.out.println("Asset already exist!");
				ConnectionBean.closeConnection(rs, ps, conn);
				return;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
	
		//adding the asset	
		 query="INSERT INTO  `Asset` (`assetCode`, `label`, `type`, `quarterlyDividend`, `baseRateOfReturn`, `omega`, `totalValue`) VALUES (?, ?, 'P', ?, ?, ?, ?)";
		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, assetCode);
			ps.setString(2, label);
			ps.setDouble(3, quarterlyDividend);
			ps.setDouble(4, baseRateOfReturn*100);
			ps.setDouble(5, omega);
			ps.setDouble(6, totalValue);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);
	}

	
	/**
	 * Adds a stock asset record to the database with the
	 * provided data. 
	 * @param assetCode
	 * @param label
	 * @param quarterlyDividend
	 * @param baseRateOfReturn
	 * @param omega
	 * @param stockSymbol
	 * @param sharePrice
	 */

	public static void addStock(String assetCode, String label, Double quarterlyDividend, 
			Double baseRateOfReturn, Double omega, String stockSymbol, Double sharePrice) {
		Connection conn= ConnectionBean.getConnection();
		//check if the asset exist
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="SELECT AssetID FROM Asset WHERE assetCode=? ";
		
		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, assetCode);
			rs = ps.executeQuery();
			if (rs.next()){//asset already exist
				System.out.println("Asset already exist!");
				ConnectionBean.closeConnection(rs, ps, conn);
				return;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		
		//adding the asset
		query="INSERT INTO  `Asset` (`assetCode`, `label`, `type`, `quarterlyDividend`, `baseRateOfReturn`, `omega`, `stockSymbol`, `sharePrice`) VALUES (?, ?, 'S', ?, ?, ? , ? , ?)";

		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, assetCode);
			ps.setString(2, label);
			ps.setDouble(3, quarterlyDividend);
			ps.setDouble(4, baseRateOfReturn*100);
			ps.setDouble(5, omega);
			ps.setString(6, stockSymbol);
			ps.setDouble(7, sharePrice);
			
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);
	}
	
	/**
	 * Removes all portfolio records from the database
	 */
	public static void removeAllPortfolios() {
		Connection conn= ConnectionBean.getConnection();
		String query="SELECT portfolioCode, PortfolioID FROM Portfolio ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try{
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()){
				removePortfolio(rs.getString("portfolioCode"));
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);
	}
	

	/**
	 * Removes the portfolio record from the database corresponding to the
	 * provided <code>portfolioCode</code>
	 * @param portfolioCode
	 */
	public static void removePortfolio(String portfolioCode) {
		//first to check if we have this portfolio in database
				Connection conn= ConnectionBean.getConnection();
				String query="SELECT portfolioCode, PortfolioID FROM Portfolio WHERE portfolioCode= ? ";
				PreparedStatement ps=null;
				ResultSet rs=null;
				int PortfolioID=0;
				
				try{
					ps = conn.prepareStatement(query);
					ps.setString(1, portfolioCode);
					rs = ps.executeQuery();
					if (!rs.next()){//portfolio does not exist in database, no need to do anything
						System.out.println("portfolio does not exist!");
						ConnectionBean.closeConnection(rs, ps, conn);
						return;
					}
					 PortfolioID=rs.getInt("PortfolioID");
					rs.close();
					} catch (SQLException e) {
						System.out.println("SQLException: ");
						e.printStackTrace();
						log.error("SQLException: ", e);
						throw new RuntimeException(e);
					}
				
				// the process of removing portfolio
				//we need to clear the portfolioAsset and then the portfolio
				//as an all-or-nothing transaction
				List<Integer> PortfolioAssetIDList= new ArrayList<Integer>();

				// get PortfolioAssetID that are associated with this portfolio.
				query="SELECT PortfolioAssetID FROM PortfolioAsset WHERE PortfolioID=? ";				
				try{
					ps = conn.prepareStatement(query);
					ps.setInt(1, PortfolioID);
					rs = ps.executeQuery();
					while (rs.next()){
						//put PortfolioAssetID into an ArrayList
						PortfolioAssetIDList.add(rs.getInt("PortfolioAssetID"));
						
					}//end while
						
					rs.close();
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
				}

				//removing record from PortfolioAsset and the portfolio
				try{
					conn.setAutoCommit(false);
					//removing PortfolioAsset
					query="DELETE FROM `PortfolioAsset` WHERE `PortfolioAssetID`= ? ";
					for (int i :PortfolioAssetIDList){
						ps = conn.prepareStatement(query);
						ps.setInt(1, i);
						ps.executeUpdate();
					}
					//removing the portfolio
					query="DELETE FROM Portfolio WHERE PortfolioID=? ";
						ps = conn.prepareStatement(query);
						ps.setInt(1, PortfolioID);
						ps.executeUpdate();	
					conn.commit();
				} catch (SQLException e) {
					try {
						conn.rollback();
					} catch (SQLException e2) {
						System.out.println("SQLException attempting to rollback: ");
						e2.printStackTrace();
					}
					System.out.println("SQLException: ");
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
				}
				ConnectionBean.closeConnection(rs, ps, conn);	
	}
	
	/**
	 * Adds a portfolio records to the database with the given data.  If the portfolio has no
	 * beneficiary, the <code>beneficiaryCode</code> will be <code>null</code>
	 * @param portfolioCode
	 * @param ownerCode
	 * @param managerCode
	 * @param beneficiaryCode
	 */
	public static void addPortfolio(String portfolioCode, String ownerCode, String managerCode, String beneficiaryCode) {
		//first to check if we have this portfolio in database
		Connection conn= ConnectionBean.getConnection();
		String query="SELECT portfolioCode, PortfolioID FROM Portfolio WHERE portfolioCode= ? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, portfolioCode);
			rs = ps.executeQuery();
			if (rs.next()){//portfolio  exist in database,can not add again
				System.out.println("portfolio already exist!");
				ConnectionBean.closeConnection(rs, ps, conn);
				return;
			}
			} catch (SQLException e) {
				System.out.println("SQLException: ");
				e.printStackTrace();
				log.error("SQLException: ", e);
				throw new RuntimeException(e);
			}
		
		//make sure the person record exists first
			Person o=PersonBean.getDetailedPersonByCode(ownerCode);
			Person m=PersonBean.getDetailedPersonByCode(managerCode);
			Person b=PersonBean.getDetailedPersonByCode(beneficiaryCode);
			if (beneficiaryCode != null){
				if (o==null || m==null || b==null){
					// at least one person does not exist
					System.out.println("at least one person specified does not exist");
					ConnectionBean.closeConnection(rs, ps, conn);
					return;
				}
				 query="INSERT INTO `Portfolio` (`portfolioCode`, `OwnerID`, `BrokerID`, `BeneficiaryID`) VALUES (?, ?, ?, ?)";
				 ps=null;
				 rs=null;
				 try{
					ps = conn.prepareStatement(query);
					ps.setString(1, portfolioCode);
					ps.setInt(2, o.PersonID);
					ps.setInt(3, m.PersonID);
					ps.setInt(4, b.PersonID);	
					ps.executeUpdate();
					
					} catch (SQLException e) {
						System.out.println("SQLException: ");
						e.printStackTrace();
						log.error("SQLException: ", e);
						throw new RuntimeException(e);
					}
				ConnectionBean.closeConnection(rs, ps, conn);
			}
			else{//beneficiaryCode is null ,do not check if this person exist
				if (o==null || m==null){
					// at least one person does not exist
					System.out.println("at least one person specified does not exist");
					ConnectionBean.closeConnection(rs, ps, conn);
					return;
				}
				 query="INSERT INTO `Portfolio` (`portfolioCode`, `OwnerID`, `BrokerID`, `BeneficiaryID`) VALUES (?, ?, ?, null)";
				 ps=null;
				 rs=null;
 				 try{
					ps = conn.prepareStatement(query);
					ps.setString(1, portfolioCode);
					ps.setInt(2, o.PersonID);
					ps.setInt(3, m.PersonID);	
					ps.executeUpdate();
					
					} catch (SQLException e) {
						System.out.println("SQLException: ");
						e.printStackTrace();
						log.error("SQLException: ", e);
						throw new RuntimeException(e);
					}
				ConnectionBean.closeConnection(rs, ps, conn);
				}			
	}
	

	/**
	 * Associates the asset record corresponding to <code>assetCode</code> with the 
	 * portfolio corresponding to the provided <code>portfolioCode</code>.  The third 
	 * parameter, <code>value</code> is interpreted as a <i>balance</i>, <i>number of shares</i>
	 * or <i>stake percentage</i> depending on the type of asset the <code>assetCode</code> is
	 * associated with.
	 * @param portfolioCode
	 * @param assetCode
	 * @param value
	 */
	public static void addAsset(String portfolioCode, String assetCode, double value) {
		//1) check if the portfolio exists, if it does not exist, do nothing, if exists, get the PortfolioID
			// checking if we have this portfolio in database
		Connection conn= ConnectionBean.getConnection();
		String query="SELECT portfolioCode, PortfolioID FROM Portfolio WHERE portfolioCode= ? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		int PortfolioID;
		int AssetID;
		String type;
		
		try{
			ps = conn.prepareStatement(query);
			ps.setString(1, portfolioCode);
			rs = ps.executeQuery();
			if (!rs.next()){//portfolio does not exist in database, no need to do anything
				System.out.println("portfolio does not exist!");
				ConnectionBean.closeConnection(rs, ps, conn);
				return;
			}
			//the Portfolio exist get the PortfolioID
			 PortfolioID=rs.getInt("PortfolioID");
			rs.close();
			} catch (SQLException e) {
				System.out.println("SQLException: ");
				e.printStackTrace();
				log.error("SQLException: ", e);
				throw new RuntimeException(e);
			}
		//2) check if the asset exists, if does not exist, do nothing, if exists, find the AssetID then associate it with the Portfolio in PortfolioAsset table
			// checking if we have this asset in database
				try{
					ps = conn.prepareStatement("SELECT AssetID, type "+
							" FROM Asset WHERE assetCode= ? ");
					ps.setString(1, assetCode);
					rs = ps.executeQuery();
					if (!rs.next()){//asset does not exist in database, no need to do anything
						System.out.println("asset does not exist!");
						ConnectionBean.closeConnection(rs, ps, conn);
						return;
					}
					//the  asset exist getting  AssetID
					 AssetID=rs.getInt("AssetID");
					 type=rs.getString("type");
					 
					
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
				}
		
				//Associate the asset with the portfolio
					try{
						ps = conn.prepareStatement("INSERT INTO `PortfolioAsset` (`PortfolioID`, `AssetID`, `value`) VALUES (?, ?, ? ) ");
						ps.setInt(1, PortfolioID);
						ps.setInt(2, AssetID);
						if (type.equals("P")){
							ps.setDouble(3, value*100);
						}
						else{
							ps.setDouble(3, value);
						}
						
						ps.executeUpdate();
					} catch (SQLException e) {
						System.out.println("SQLException: ");
						e.printStackTrace();
						log.error("SQLException: ", e);
						throw new RuntimeException(e);
					}				
				ConnectionBean.closeConnection(rs, ps, conn);
	}//end class
	
	
//******************************other help method******************************************	
	public static int addState(String state){
		//checking if the state exists
		Connection conn=ConnectionBean.getConnection();
		String query;
		query="SELECT state, StateID FROM State WHERE state=?";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, state);
			rs = ps.executeQuery();

		  if(rs.next()){//state already exist
			  int StateID = rs.getInt("StateID"); 
			  ConnectionBean.closeConnection(rs, ps, conn);
			  return StateID; 
			   
		  }
		  rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		
	  //adding this state into State table
				try {
					ps = conn.prepareStatement( " INSERT INTO State (state) VALUES (?) ");
					ps.setString(1, state);
					ps.executeUpdate();
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
				}	
				//getting the StateID of newly added State
				int StateID=0;
				try{
					ps = conn.prepareStatement("SELECT state, StateID FROM State WHERE state= ? ");
					ps.setString(1, state);
					rs = ps.executeQuery();
					if (rs.next()){
						 StateID = rs.getInt("StateID"); 
					}
					rs.close();
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
				}
		ConnectionBean.closeConnection(rs, ps, conn);
		return StateID;
}

	public static int addCountry(String country){
		//checking if the state exists
		Connection conn=ConnectionBean.getConnection();
		String query;
		query="SELECT country, CountryID FROM Country WHERE country=?";
		
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, country);
			rs = ps.executeQuery();

		  if(rs.next()){//state already exist
			  int CountryID = rs.getInt("CountryID");
			  ConnectionBean.closeConnection(rs, ps, conn);
			  return CountryID; 
		  }
		  rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}		
		
	  //adding this state into State table
				try {
					ps = conn.prepareStatement( " INSERT INTO Country (country) VALUES (?) ");
					ps.setString(1, country);
					ps.executeUpdate();
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
				}
					
					//getting the StateID of newly added State
				int CountryID=0;
				
				try{
					ps = conn.prepareStatement("SELECT CountryID, country FROM Country WHERE country= ? ");
					ps.setString(1, country);
					rs = ps.executeQuery();
					if (rs.next()){
						CountryID = rs.getInt("CountryID"); 
					}
					
					rs.close();
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					log.error("SQLException: ", e);
					throw new RuntimeException(e);
				}

		ConnectionBean.closeConnection(rs, ps, conn);		
		return CountryID;
}

	public static void removeEmailByID(int EmailID){
		if (EmailID==0){
			return;
		}
		Connection conn=ConnectionBean.getConnection();
		String query="DELETE FROM `Email` WHERE `EmailID`=? ";
		PreparedStatement ps=null;
		ResultSet rs=null;		
		try {
			ps = conn.prepareStatement( query);
			ps.setInt(1, EmailID);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);	
	}
	
	public static void removeAddressByID(int AddressID){
		if (AddressID==0){
			return;
		}
		Connection conn=ConnectionBean.getConnection();
		String query="DELETE FROM `Address` WHERE `AddressID`=? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			ps = conn.prepareStatement( query);
			ps.setInt(1, AddressID);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("SQLException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);	
	}
	
}
