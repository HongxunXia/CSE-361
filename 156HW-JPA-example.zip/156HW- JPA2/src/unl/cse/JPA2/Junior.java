package unl.cse.JPA2;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity(name="Junior")
@DiscriminatorValue("J")
public class Junior extends Brokers  {

//*********************************************
//constructor
	
	private Junior() { super(); }
	/**
	 * @param code
	 * @param SEC
	 * @param name
	 * @param address
	 * @param emails
	 */
	public Junior(String code, String SEC, String name, Address address,
			String[] emails,int PersonID) {
		super(code, SEC, name, address, emails,PersonID);
		this.annualFee=50;
		this.commission=0.02;

	}

	@Override
	public String getType() {
		return "J";
	}

}
