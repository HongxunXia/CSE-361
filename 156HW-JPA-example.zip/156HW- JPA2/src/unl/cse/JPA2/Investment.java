package unl.cse.JPA2;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;


@Entity(name="Investment")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="type")
public abstract class Investment extends Assets{
	
	@Column(name="quarterlyDividend", nullable=false)
	 double quarterlyDividend;
	
	@Column(name="baseRateOfReturn", nullable=false)
	 double baseRateOfReturn;
	
	@Column(name="omega", nullable=false)
	 double omega;
//*******************************************

//constructor
	/**
	 * @param assetCode
	 * @param type
	 * @param label
	 */
	protected Investment(){}
	
	public Investment(String assetCode, String type, String label,double quarterlyDividend,double baseRateOfReturn, double omega) {
		super(assetCode, type, label);
		this.quarterlyDividend=quarterlyDividend;
		this.baseRateOfReturn=baseRateOfReturn;
		this.omega=omega;
	}
//*********************************************
	//getters
	


	public double getQuarterlyDividend() {
		return quarterlyDividend;
	}
	public double getBaseRateOfReturn() {
		return baseRateOfReturn;
	}
	public double getOmega() {
		return omega;
	}


}
