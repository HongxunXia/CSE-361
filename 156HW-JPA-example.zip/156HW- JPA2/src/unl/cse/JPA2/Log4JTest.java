package unl.cse.JPA2;

import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;

public class Log4JTest {

	private static Logger log = Logger.getLogger(Log4JTest.class);
	
	public static void main(String[] args) {
		BasicConfigurator.configure();
		
		log.debug("This is an debug message!");
		log.info("Informational Message!");
		log.error("This is an error message! You have a database issue!");
		
		tryCatch();
		Report obj = new Report();
		obj.generateReport();
	}
	
	private static void tryCatch() {
		try {
			throw new Exception("Exception");
		} catch (Exception e) {
			System.out.println("SQLException: ");
			log.error("This is an error message! You have a database issue!", e);
		}
	}
}
