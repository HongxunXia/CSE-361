package unl.cse.JPA2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
//import java.io.FileOutputStream;
//import java.io.File;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;



@SuppressWarnings("unused")

@Entity
@Table(name="Person")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="type")
@DiscriminatorValue("C")
public  class Person {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PersonID", nullable=true)
	int PersonID;
	
	@Column(name="personcode", nullable=true)
	 String code;// Person Code – the unique alpha-numeric designation from the old system
	//private String brokerData;//if the user is not a broker, this field will be empty. Otherwise it will contain two pieces of data separated by a comma. The first piece is either E or J (indicating an Expert or Junior broker) and the second is the person’s SEC identifier
	// String name;// a String in the format (lastName, firstName)
	
	@Column(name="lastName", nullable=true)
	 String lastName;
	
	@Column(name="firstName", nullable=true)
	 String firstName;
	
	@Transient
	 Address address; // an class containing fields:  STREET,CITY,STATE,ZIP,COUNTRY
	@Transient
	 String emails[];// an array
	 
	

/**************************************************************/
	protected Person(){}
// this constructor is for non brokers
	public Person(String code,String  name, Address address,
			String emails[],int PersonID) {
		
		this.code = code;
		String NameToken[]=name.split(",");
		this.lastName=NameToken[0]; // name is an object
		this.firstName=NameToken[1].trim();
		this.address=address;// address is an object
		this.emails=emails;
		this.PersonID=PersonID;
		
	}
	
/***********************************************************/	
	
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return lastName+", "+firstName;
	}

	
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Address getAddress() {
		return address;
	}

	
	public String[] getEmails() {
		return emails;
	}

	public void setEmails(String[] emails) {
		this.emails = emails;
	}
	
	
	
/*******************other methods**************************/

	public void print(){
		//String token[] = this.getName.split(",");
		System.out.println("{");
		System.out.println("  \"code\" : "+"\""+this.code+"\",");
		System.out.println("  \"name\": "+ " {");
		System.out.println("    \"first\": "+"\""+this.firstName+"\",");
		System.out.println("    \"Last\": "+"\""+this.lastName+"\"");
		System.out.println("  },");
		
		System.out.println("  \"address\": "+"{");
		System.out.println("    \"street\": "+"\""+this.address.getStreet()+"\",");
		System.out.println("    \"city\": "+"\""+this.address.getCity()+"\",");
		System.out.println("    \"state\": "+"\""+this.address.getState()+"\",");
		System.out.println("    \"zip\": "+"\""+this.address.getZip()+"\",");
		System.out.println("    \"country\": "+"\""+this.address.getCountry()+"\"");
		System.out.println("  },");

		if (this.getEmails().length==0){
			System.out.println("  \"emails\": "+ " []");			
		}
		else {
			System.out.println("  \"emails\": "+ " [");
			for(int i=0;i<getEmails().length-1;i++){
				System.out.println("    \""+this.getEmails()[i]+"\",");
			}
			System.out.println("    \""+this.getEmails()[this.getEmails().length-1]+"\"");
			System.out.println("  ]");
		}
		//System.out.println("},");
		
	}

	
	//****************output data to Json file without using lib - begin**************
	public static void tojson(int count,ArrayList<Person> personList,String file){
		
			try {
				PrintWriter out = new PrintWriter(file);
				
				out.write("{\n");
				out.write("\"Person\":" +"[\n");
				for (int i=0;i<count;i++){
					String token[]=personList.get(i).getName().split(",");
					out.write("{\n");
					out.write("  \"code\" : "+"\""+personList.get(i).getCode()+"\",\n");
					out.write("  \"name\": "+ " {\n");
					out.write("    \"first\": "+"\""+token[1]+"\",\n");
					out.write("    \"Last\": "+"\""+token[0]+"\"\n");
					out.write("  },\n");

					out.write("  \"address\": "+"{\n");
					out.write("    \"street\": "+"\""+personList.get(i).getAddress().getStreet()+"\",\n");
					out.write("    \"city\": "+"\""+personList.get(i).getAddress().getCity()+"\",\n");
					out.write("    \"state\": "+"\""+personList.get(i).getAddress().getState()+"\",\n");
					out.write("    \"zip\": "+"\""+personList.get(i).getAddress().getZip()+"\",\n");
					out.write("    \"country\": "+"\""+personList.get(i).getAddress().getCountry()+"\"\n");
					out.write("  },\n");

					if (personList.get(i).getEmails().length==0){
						out.write("  \"emails\": "+ " []\n");						
					}
					else {
						out.write("  \"emails\": "+ " [\n");
						for(int i1=0;i1<personList.get(i1).getEmails().length-1;i1++){
							
							out.write("    \""+personList.get(i1).getEmails()[i1]+"\",\n");
						}
						out.write("    \""+personList.get(i).getEmails()[personList.get(i).getEmails().length-1]+"\"\n");
						out.write("  ]\n");
					
						if (i!=count-1){
							out.write("},\n");
						}
						else {
							
						}
				}
				}//end for
					
				out.write("}\n");
				out.write("]\n");
				out.write("}\n");
			
				out.close();
				}//end try
			
						catch (FileNotFoundException fnfe) {
				fnfe.printStackTrace(); }
	}
			//****************output data to Json file without using lib - end**************
	

	public static int personCount(){
		//***************************************************************************/
		//reading files from Person.dat
		Scanner s=null;
		
		try {
			 s = new Scanner(new File("data/Persons.dat"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String line;
		line=s.nextLine().replaceAll("\n", "");//read a line and get ride of "\n"
		int count=Integer.parseInt(line);// get total number of person in the data file
		s.close();
		return count;
	}
	
	
	

	public static Map<String,Person> personParser(){// this method reads the file Person.dat and create instance and return a map
		//from person code to the reference of a person instance
		//***************************************************************************/
		Map<String,Person> personMap = new HashMap<String, Person>();
		//reading files from Person.dat
		Scanner s=null;
		//ArrayList<Person> personList = new ArrayList<Person>();
		
		
		try {
			 s = new Scanner(new File("data/Persons.dat"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String line;
		line=s.nextLine().replaceAll("\n", "");//read a line and get ride of "\n"
		int count=Integer.parseInt(line);// get total number of person in the data file
		
		while(s.hasNext()) {
			
			line = s.nextLine();
			String tokens[] = line.split(";");
			String code = tokens[0];
			String broker=tokens[1].trim();
			String name = tokens[2];
		
			
			//create new address instance
			String address[] = tokens[3].split(",");
			Address a=new Address(null,null,null,null,null);
			if (address.length==5){
				 a =new Address(address[0],address[1],address[2],address[3],address[4]);
			}

			
			//put emails into the array "emails"
			String emails[] = {};
			if (tokens.length==5){ 
			 emails = tokens[4].split(",");
			}

			if ( broker.isEmpty()){//it is a Person 
				Person p = new Person (code,  name, a,  emails, 0);
				//add to the map
	    		personMap.put(code, p);
		
			}
			else {//it is a Broker
	    		String brokerData[] = broker.split(",");
				if (brokerData[0].equals("J")){
					Junior p=new Junior ( code, brokerData[1], name, a, emails,0);
					//add to the map
		    		personMap.put(code, p);
		    		
				}
				else if (brokerData[0].equals("E")){
					Expert p=new Expert ( code, brokerData[1], name, a, emails,0);
					//add to the map
		    		personMap.put(code, p);
		    		
				}
	    		
			}
			
		}//end while
		return personMap;
		
	}
	
}//end class