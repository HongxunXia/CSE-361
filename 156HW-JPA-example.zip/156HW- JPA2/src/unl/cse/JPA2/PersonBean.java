package unl.cse.JPA2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;

public class PersonBean {
	
	private static Logger log = Logger.getLogger(PersonBean.class);
	
	public static void main(String[] args) {
		BasicConfigurator.configure();
		//===== test code - commented out ======================================
		//System.out.println("person count= "+PersonBean.getAllPerson().size());
		//PersonBean.getAllPerson();
		//System.out.println(PersonBean.getAllPerson().get(10).name);
		//System.out.println(PersonBean.getDetialedPersonByID(23).name);
		//System.out.println(PersonBean.getDetialedPersonByCode("L337").name);
		//if (PersonBean.getDetialedPerson(23)==null){
		//System.out.println("null");
		//===========================
	}
	
	public static Map<Integer, Person> getAllPerson(){// this method reads the data from database and create all person instance and return
		//a map which is from person code to the reference of a person instance
		//*************************************************************
		Map<Integer,Person> personMap = new HashMap<Integer, Person>();
		//reading files from the database
		
		/*
		 * Query the database and get the person info 
		 *  create a perosn object with all
		 * details specified
		 */
		Connection conn=ConnectionBean.getConnection();
		
		String query ="SELECT *"+
		"FROM Person p LEFT JOIN Email e ON p.PersonID=e.PersonID LEFT JOIN Address a ON p.PersonID=a.PersonID"+
				" LEFT JOIN State s ON s.StateID= a.StateID JOIN Country c ON c.CountryID=a.CountryID";
		
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
			int AddressID=rs.getInt("AddressID");
			String code=rs.getString("personCode");
			String lastName=rs.getString("lastName");
			String firstName=rs.getString("firstName");
			String name=lastName+", "+firstName;
			String secCode=rs.getString("secCode");
			String type = rs.getString("type");
			String street=rs.getString("street");
			String city=rs.getString("city");
			String state=rs.getString("state");
			String country=rs.getString("country");
			String zip=rs.getString("zip");
			String email=rs.getString("emailAddress");
			String emails[]={};
			int PersonID=rs.getInt("PersonID");
			
			//check if this person has been created before	
					if (personMap.containsKey(PersonID)){
						//this person has already been created before, it has more than one email
						//update the email
						
						String emailtemp="";
						for (String k: personMap.get(PersonID).emails){
							emailtemp=email+","+k;
						}
						emails=emailtemp.split(",");
						
					}
					else { //a new person. creating this person object 
						if (email!=null ){//this person has an email, if does not have one, then by default it is empty
						String emailtemp=email;
					    emails=emailtemp.split(",");
						}
							//create new address instance
							Address a =new Address(street,city,state,zip,country,AddressID);
							
							if (type== null){//this is a Person
								Person c = new Person (code,  name, a,  emails,PersonID);
								//add to the map
					    		personMap.put(PersonID, c);
								
							}
							else if (type.equals("E")){//this is an Expert broker
								Expert e=new Expert ( code, secCode, name, a, emails,PersonID);
								//add to the map
					    		personMap.put(PersonID, e);
							}
							else if (type.equals("J")){//this is an Junior broker
								Junior j=new Junior ( code, secCode, name, a, emails,PersonID);
								//add to the map
					    		personMap.put(PersonID, j);
							}		
			}//end for
		  }//end while	
			rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("ClassNotFoundException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);
		return personMap;
	}//end getAllPerson()
	
	
	
public static Person getDetailedPersonByID(int PersonID){
	//this method will return the desired person object (including all info) by reading data from the database
	// if this person does not exist, then return null
	Map<Integer,Person> checkPersonMap = new HashMap<Integer, Person>();
	
		Connection conn=ConnectionBean.getConnection();
	
		String query ="SELECT e.EmailID,a.AddressID, personCode,lastName, firstName,secCode,type,street,city,state,country,zip,emailAddress "+
				"FROM Person p LEFT JOIN Email e ON p.PersonID=e.PersonID LEFT JOIN Address a ON p.PersonID=a.PersonID"+
						"LEFT JOIN State s ON s.StateID= a.StateID LEFT JOIN Country c ON c.CountryID=a.CountryID"
						+" WHERE p.PersonID=?";
				
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, PersonID);
			rs = ps.executeQuery();
			
		while (rs.next()) {
			int AddressID=rs.getInt("AddressID");
			String code=rs.getString("personCode");
			String lastName=rs.getString("lastName");
			String firstName=rs.getString("firstName");
			String name=lastName+", "+firstName;
			String secCode=rs.getString("secCode");
			String type = rs.getString("type");
			String street=rs.getString("street");
			String city=rs.getString("city");
			String state=rs.getString("state");
			String country=rs.getString("country");
			String zip=rs.getString("zip");
			String email=rs.getString("emailAddress");
			String emails[]={};
			
			//check if this person has been created before	
					if (checkPersonMap.containsKey(PersonID)){
						//this person is already been created before, it has more than one email
						//update the email
						
						String emailtemp=null;
						for (String k: checkPersonMap.get(PersonID).emails){
							emailtemp=email+","+k;
						}
						emails=emailtemp.split(",");
						
					}
					else { //a new person. creating this person object 
						if (email!=null ){//this person has an email, if does not have one, then by default it is empty
						String emailtemp=email;
					    emails=emailtemp.split(",");
						}
							//create new address instance
							Address a =new Address(street,city,state,zip,country,AddressID);
							
							if (type== null){//this is a Person
								Person p = new Person (code,  name, a,  emails,PersonID);
								//add to the map
								checkPersonMap.put(PersonID, p);
								
							}
							else if (type.equals("E")){//this is an Expert broker
								Expert p=new Expert ( code, secCode, name, a, emails,PersonID);
								//add to the map
								checkPersonMap.put(PersonID, p);
							}
							else if (type.equals("J")){//this is an Junior broker
								Junior p=new Junior ( code, secCode, name, a, emails,PersonID);
								//add to the map
								checkPersonMap.put(PersonID, p);
							}
					}
		  }//end while
			rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("ClassNotFoundException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);
		return checkPersonMap.get(PersonID);
	}//end getDetailedPersonByID
	
public static Person getDetailedPersonByCode(String personCode){
	//this method will return the desired person object (including all info) by reading data from the database
	// if this person does not exist, then return null
	Map<String,Person> checkPersonMap = new HashMap<String, Person>();
	
		Connection conn=ConnectionBean.getConnection();

		String query ="SELECT e.EmailID,a.AddressID, p.PersonID, lastName, firstName, secCode,type,street,city,state,country,zip,emailAddress "+
				"FROM Person p LEFT JOIN Email e ON p.PersonID=e.PersonID LEFT JOIN Address a ON p.PersonID=a.PersonID"+
						" LEFT JOIN State s ON s.StateID= a.StateID LEFT JOIN Country c ON c.CountryID=a.CountryID"
						+" WHERE p.personCode=?";
		
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, personCode);
			rs = ps.executeQuery();
			
		while (rs.next()) {
			int PersonID=rs.getInt("PersonID");
			int AddressID=rs.getInt("AddressID");
			String lastName=rs.getString("lastName");
			String firstName=rs.getString("firstName");
			String name=lastName+", "+firstName;
			String secCode=rs.getString("secCode");
			String type = rs.getString("type");
			String street=rs.getString("street");
			String city=rs.getString("city");
			String state=rs.getString("state");
			String country=rs.getString("country");
			String zip=rs.getString("zip");
			String email=rs.getString("emailAddress");
			String emails[]={};
			
			//check if this person has been created before	
					if (checkPersonMap.containsKey(personCode)){
						//this person is already been created before, it has more than one email
						//update the email
						
						String emailtemp=null;
						for (String k: checkPersonMap.get(personCode).emails){
							emailtemp=email+","+k;
						}
						emails=emailtemp.split(",");
						
					}
					else { //a new person. creating this person object 
						if (email!=null ){//this person has an email, if does not have one, then by default it is empty
						String emailtemp=email;
					    emails=emailtemp.split(",");
						}
							//create new address instance
							Address a =new Address(street,city,state,zip,country,AddressID);
							
							if (type== null){//this is a Person
								Person p = new Person (personCode,  name, a,  emails,PersonID);
								//add to the map
								checkPersonMap.put(personCode, p);
								
							}
							else if (type.equals("E")){//this is an Expert broker
								Expert p=new Expert ( personCode, secCode, name, a, emails,PersonID);
								//add to the map
								checkPersonMap.put(personCode, p);
							}
							else if (type.equals("J")){//this is an Junior broker
								Junior p=new Junior ( personCode, secCode, name, a, emails,PersonID);
								//add to the map
								checkPersonMap.put(personCode, p);
							}
					}
		  }//end while
			rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			log.error("ClassNotFoundException: ", e);
			throw new RuntimeException(e);
		}
		ConnectionBean.closeConnection(rs, ps, conn);
		return checkPersonMap.get(personCode);
	}// end getDetailedPersonByCode

}//end class
