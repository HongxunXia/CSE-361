package unl.cse.JPA2;

import org.apache.log4j.Logger;

public class Report {

	static Logger logger = Logger.getLogger(Report.class);
	
	public void generateReport()
	{
		logger.debug("default debug message");
		logger.info("default info message");
		logger.warn("default warn message");
		logger.error("error message, probably a connection issue"); //what should this say
		logger.fatal("fatal message"); //what should this say
	}
}
