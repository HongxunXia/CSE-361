package unl.cse.JPA2;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity(name="Private")
@DiscriminatorValue("P")
public class Private extends Investment {
	
	@Column(name="totalValue", nullable=false)
	private double totalValue;
	
	@Column(name="percentageOfStake", nullable=false)
	private Double percentageOfStake;

//*****************************************
	//constructor
	
	
	/**
	 * @param assetCode
	 * @param type
	 * @param label
	 * @param quarterlyDividend
	 * @param baseRateOfReturn
	 * @param omega
	 */
	private Private(){}
	
	public Private(String assetCode, String type, String label,
			double quarterlyDividend, double baseRateOfReturn, double omega,double totalValue) {
		super(assetCode, type, label, quarterlyDividend, baseRateOfReturn, omega);
		this.totalValue= totalValue;
		this.percentageOfStake=0.0;
	}
	
/*	PrivateInvestmentshavethefollowingformat:
		code;P;label;quarterly dividend;base rate of return;omega measure;total value*/
	
	
//****************************************
	//getters
	public double getPercentageOfStake() {
		return percentageOfStake;
	}


	public void setPercentageOfStake(Double percentageOfStake) {
		this.percentageOfStake = percentageOfStake;
	}


	public double getTotalValue() {
		return totalValue;
	}


//******************************************
	//other methods
	@Override
	public Private makeCopy() {
		Private p= new Private(null,null,null,0,0,0,0);
		p.assetCode=this.assetCode;
		p.baseRateOfReturn=this.baseRateOfReturn;
		p.label=this.label;
		p.quarterlyDividend=this.quarterlyDividend;
		p.omega=this.omega;
		p.totalValue=this.totalValue;
		p.percentageOfStake=this.percentageOfStake;
		return p;
	}
	
	@Override
	public double getValue() {	
		return this.totalValue*this.percentageOfStake/100.0;
	}

	@Override
	public double getAnnualReturn() {
		double annualReturn=(this.baseRateOfReturn/100.0)*this.getValue()+4*this.quarterlyDividend*(this.percentageOfStake/100.0);
		return annualReturn;
	}

	@Override
	public double getRisk() {
		return 0.25+this.omega;
	}

	@Override
	public double getReturnRate() {
		double returnRate=(this.getAnnualReturn()/this.getValue())*100;
		return returnRate;
	}

	@Override
	public String getType() {
		return "P";
	}
	
}
