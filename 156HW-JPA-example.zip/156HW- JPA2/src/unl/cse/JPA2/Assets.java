package unl.cse.JPA2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="Asset")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="type")
public abstract class Assets {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="AssetID", nullable=true)
	 String assetCode;
	
	@Column(name="label", nullable=true)
	 String label;
	

	
	//@Column(name="type", nullable=true)
	//@Transient
	 //String type;
	
/*	 double risk;
	 double returnRate;
	 double annualReturn;*/
	
	protected Assets(){}
	//Constructor for Deposit Accounts  Type"D"
	public Assets(String assetCode,String type, String label) {
		this.assetCode = assetCode;
		this.label = label;
	}

//*************************************************************
	//getters	
	public String getAssetCode() {
		return assetCode;
	}
	
	
	
	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getLabel() {
		return label;
	}

	


//***************************************************************************************
//other methods
	//****************output data to Json file without using lib  begain**************
	public static void tojson(int count2,ArrayList<Assets> assetList,String fileName){	
	
			try {
				PrintWriter out = new PrintWriter(fileName);
				
				out.write("{\n");
				out.write("\"assets\":" +"[\n");
				for (int i=0;i<count2;i++){
					out.write("{\n");
					out.write("  \"assetCode\" : "+"\""+assetList.get(i).getAssetCode()+"\",\n");
					out.write("  \"label\" : "+"\""+assetList.get(i).getLabel()+"\",\n");
					out.write("  \"type\" : "+"\""+assetList.get(i).getType()+"\",\n");
					if (assetList.get(i).getType().equals("D")){
						out.write("  \"apr\" : "+"\""+((Deposit) assetList.get(i)).getApr()+"\",\n");
					}
					else {
					
					out.write("  \"quarterlyDividend\" : "+"\""+((Investment) assetList.get(i)).getQuarterlyDividend()+"\",\n");
					out.write("  \"baseRateOfReturn\" : "+"\""+((Investment) assetList.get(i)).getBaseRateOfReturn()+"\",\n");
					out.write("  \"omega\" : "+"\""+((Investment) assetList.get(i)).getOmega()+"\",\n");
						if (assetList.get(i).getType().equals("S")){
							out.write("  \"stockSymbol\" : "+"\""+((Stocks) assetList.get(i)).getStockSymbol()+"\",\n");
							out.write("  \"sharePrice\" : "+"\""+((Stocks) assetList.get(i)).getSharePrice()+"\",\n");
						}
						else if(assetList.get(i).getType().equals("P")){
							out.write("  \"totalValue\" : "+"\""+((Private) assetList.get(i)).getTotalValue()+"\",\n");
						}
						
					}//end if 
					if (i!=count2-1){
						out.write("},\n");
					}
					else {
						
					}
				}//end for	
				out.write("}\n");
				out.write("]\n");
				out.write("}\n");
			
				out.close();
				}//end try
			
						catch (FileNotFoundException fnfe) {
				fnfe.printStackTrace(); }
			
	}
			//****************output data to Json file without using lib  end**************


	public static int assetsCount(){
		//reading files from Assets.dat
    	Scanner s2=null;
    	
		try {
			 s2 = new Scanner(new File("data/Assets.dat"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String line2;
		line2=s2.nextLine().replaceAll("\n", "");//read a line and get ride of "\n"
		int count2=Integer.parseInt(line2);// get total number of assets in the data file
		s2.close();
				
		return count2;
	}
	
	@SuppressWarnings("unused")
	public static  Map<String,Assets> assetsParser() {
		//this method reads Assets.dat file and create Assets instance and returns a map from assetcode to asset
	 	
		Map<String,Assets> assetMap = new HashMap<String, Assets>();
    	//reading files from Assets.dat
    	Scanner s2=null;
    	//ArrayList<Assets> assetList = new ArrayList<Assets>();
    	
		try {
			 s2 = new Scanner(new File("data/Assets.dat"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String line2;
		line2=s2.nextLine().replaceAll("\n", "");//read a line and get ride of "\n"
		int count2=Integer.parseInt(line2);// get total number of assets in the data file
		//Assets arr2[]= new Assets[count2] ; // create an array to hold all assets instance
		
		int j=0;//this j keeps track how many Assets has been created
    	while(s2.hasNext()) {
    		
    		line2 = s2.nextLine();
    		String tokens[] = line2.split(";");
    		String code = tokens[0];
    		String type=tokens[1];
    		String label=tokens[2];
    		
    		double quarterlyDividend;
    		double baseRateOfReturn;
    		double omega;
    		
    		//System.out.println(type);
    		if (type.equals("D")){ // this is an deposit account
    			double apr=Double.parseDouble(tokens[3]);
    			//use constructor to create a new Deposit instance
    			Deposit d = new Deposit( code, type,label, apr);
    			
        		//put Deposit account d into the map
    			assetMap.put(code, d);
        		j++;	
    		}
    		else if(type.equals("S")){ // this is an Stock)
    			 quarterlyDividend=Double.parseDouble(tokens[3]);
    			 baseRateOfReturn=Double.parseDouble(tokens[4]);
    			 omega=Double.parseDouble(tokens[5]);
    			String stockSymbol=tokens[6];
    			double sharePrice=Double.parseDouble(tokens[7]);
    			//use constructor to create new Stock instance
    			Stocks stock= new Stocks(code,type,label,quarterlyDividend,
    					baseRateOfReturn,  omega,stockSymbol,sharePrice);
        		//put Stocks  stock into the map
    			assetMap.put(code, stock);
        		j++;
    			
    		}
    		else if(type.equals("P")){ // this is an Private Investment))
    			quarterlyDividend=Double.parseDouble(tokens[3]);
    			baseRateOfReturn=Double.parseDouble(tokens[4]);
   			    omega=Double.parseDouble(tokens[5]);
   			    double totalValue=Double.parseDouble(tokens[6]);
   			 Private p = new Private(code,type,label, quarterlyDividend,
   					baseRateOfReturn, omega, totalValue);
     		//put Private p into the map
 			assetMap.put(code, p);
     		j++;
    			
    		}
    		
    	}//end while(s2.hasNext())
		return assetMap;
	}

	//abstract methods
	public abstract String getType();
	public abstract  Assets makeCopy();
	public abstract double getValue();
	public abstract double getAnnualReturn();
	public abstract double getRisk();
	public abstract double getReturnRate();
	
	
//	//==========for JPA================
//	//abstract JPA methods
//		public abstract String getTypeJPA();
//		public abstract  Assets makeCopyJPA();
//		public abstract double getValueJPA();
//		public abstract double getAnnualReturnJPA();
//		public abstract double getRiskJPA();
//		public abstract double getReturnRateJPA();
	
}//end class
