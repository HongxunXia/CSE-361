package unl.cse.JPA2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;

public class PortfolioBean {

	private static Logger log = Logger.getLogger(PortfolioBean.class);
	
	public static void main(String[] args) {
		BasicConfigurator.configure();
		//System.out.println("person count= "+PersonBean.getAllPerson().size());
		//PersonBean.getAllPerson();
		//System.out.println(PersonBean.getAllPerson().get(10).name);
		//System.out.println(PersonBean.getDetialedPerson(2).name);
		
		for (Portfolio p : PortfolioBean.getAllPortfolio()){
			System.out.println(p.getCode());
			System.out.println("Assets owned:");
			for (Assets a: p.getAssetslist()){
				System.out.println(a.getAssetCode());
			}
			System.out.println(p.getAssetslist().size());
		}
	}

	public	static ArrayList<Portfolio> getAllPortfolio(){
		//this method reads data from DB, creates portfolios with corresponding properties and dumps into an ArrayList
			ArrayList<Portfolio> portfolioList = new ArrayList<Portfolio>();
			
			//use this Map to check if an portfolio has been created already or not.
			Map<Integer,Portfolio> portfolioMap= new HashMap<Integer,Portfolio>();
			
			//create All Person and a maps from reading the database 
			Map<Integer,Person> personMap = PersonBean.getAllPerson();
			Connection conn=ConnectionBean.getConnection();
		
			String query="SELECT * FROM PortfolioAsset pa JOIN Asset a ON a.AssetID=pa.AssetID JOIN Portfolio p ON p.PortfolioID= pa.PortfolioID";	
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = conn.prepareStatement(query);
				rs = ps.executeQuery();
				while (rs.next()) {
				
						//portfolio info
						int PortfolioID=rs.getInt("PortfolioID");
						String code=rs.getString("portfolioCode");
						int OwnerID=rs.getInt("OwnerID");
						int BrokerID=rs.getInt("BrokerID");
						int BeneficiaryID=rs.getInt("BeneficiaryID");
						
						//asset info
						String assetCode=rs.getString("assetCode");
						String label=rs.getString("label");
						String type=rs.getString("type");
						double value=rs.getDouble("value");
						
						//deposit info
						double apr =rs.getDouble("apr");
						
						//investment info
						double quarterlyDividend=rs.getDouble("quarterlyDividend");
						double baseRateOfReturn=rs.getDouble("baseRateOfReturn");
						double omega=rs.getDouble("omega");
						
						//Stocks info
						String stockSymbol=rs.getString("stockSymbol");
						double sharePrice=rs.getDouble("sharePrice");
						
						//Private info
						double totalValue=rs.getDouble("totalValue");
					
						//creating Assets
						Set<Assets> hashset = new HashSet<Assets>();
						
						if (type.equals("D")){
							Deposit a = new Deposit( assetCode, type,label, apr);
							a.setTotalBalance(value);
							hashset.add(a);		
						}
						else if (type.equals("S")){
							Stocks a= new Stocks(assetCode,type,label,quarterlyDividend,
			    					baseRateOfReturn, omega,stockSymbol,sharePrice);
							a.setShareOwned(value);
							hashset.add(a);
						}
						else if (type.equals("P")){
							Private a = new Private(assetCode,type,label, quarterlyDividend,
				   					baseRateOfReturn, omega, totalValue);
							a.setPercentageOfStake(value);
							hashset.add(a);
							
						}
						
						//check if this portfolio has been created before
						if (portfolioMap.containsKey(PortfolioID)){
							//already been created before, it has more than one asset
							//so update the assetlist	
							portfolioMap.get(PortfolioID).getAssetslist().addAll(hashset);
						}
						else {
							// need to create a new portfolio object
								Portfolio port= new Portfolio( code, personMap.get(OwnerID),(Brokers) personMap.get(BrokerID),
										personMap.get(BeneficiaryID), new ArrayList<Assets>(hashset));	
								portfolioMap.put(PortfolioID,port);
								portfolioList.add(port);
						}
				}//end while
				rs.close();
			} catch (SQLException e) {
				System.out.println("SQLException: ");
				e.printStackTrace();
				log.error("ClassNotFoundException: ", e);
				throw new RuntimeException(e);
			}
			ConnectionBean.closeConnection(rs, ps, conn);
		return portfolioList;
	}//end getAllPortfolio()
	
}//end class
