package unl.cse.JPA2;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity(name="Stocks")
@DiscriminatorValue("S")
public class Stocks extends Investment {
	
	@Column(name="stockSymbol", nullable=false)
	private String stockSymbol;
	
	@Column(name="sharePrice", nullable=false)
	private double sharePrice;
	
	@Column(name="shareOwned", nullable=false)
	private Double shareOwned;

	/**
	 * @param assetCode
	 * @param type
	 * @param label
	 * @param quarterlyDividend
	 * @param baseRateOfReturn
	 * @param omega
	 */
	private Stocks(){super();}
	
	public Stocks(String assetCode, String type, String label,
			double quarterlyDividend, double baseRateOfReturn, double omega,String stockSymbol,double sharePrice) {
		super(assetCode, type, label, quarterlyDividend, baseRateOfReturn, omega);
		this.stockSymbol=stockSymbol;
		this.sharePrice=sharePrice;
		this.shareOwned=0.0;

	}
	
/*	Stocks have the following format:
		code;S;label;quarterly dividend;base rate of return;omega measure;stock symbol;share price*/
	
//************************************************
	//getters and setters
	public Double getShareOwned() {
		return shareOwned;
	}


	public void setShareOwned(Double shareOwned) {
		this.shareOwned = shareOwned;
	}


	public String getStockSymbol() {
		return stockSymbol;
	}


	public double getSharePrice() {
		return sharePrice;
	}


//********************************************************
	//other methods
	@Override
	public Stocks makeCopy() {
		Stocks s= new Stocks(null,null,null,0,0,0,null,0);
		s.assetCode=this.assetCode;
		s.label=this.label;
		s.quarterlyDividend=this.quarterlyDividend;
		s.baseRateOfReturn=this.baseRateOfReturn;
		s.omega=this.omega;
		s.stockSymbol=this.stockSymbol;
		s.sharePrice=this.sharePrice;
		s.shareOwned=this.shareOwned;
		return s;
	}
	
	@Override
	public double getValue() {
		double value=this.shareOwned*this.sharePrice;
		return value;
	}

	@Override
	public double getAnnualReturn() {
		double annualReturn=(this.baseRateOfReturn/100.0)*this.getValue()+4*(this.quarterlyDividend)*this.shareOwned;
		return annualReturn;
	}

	@Override
	public double getRisk() {
		return 0.1+this.omega;
	}

	@Override
	public double getReturnRate() {
		double returnRate=(this.getAnnualReturn()/this.getValue())*100;
		return returnRate;
	}

	@Override
	public String getType() {
		
		return "S";
	}
		
}
