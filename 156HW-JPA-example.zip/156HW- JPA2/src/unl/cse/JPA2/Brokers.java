package unl.cse.JPA2;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity(name="Brokers")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="type")
public  abstract class Brokers extends Person {
	
	@Column(name="secCode", nullable=false)
	 String SEC;
	
	@Column(name="annualFee", nullable=false)
	 protected double annualFee;
	 //Junior broker have a $50.00 per-asset annual fee 
	//Expert broker have a $10.00 per-asset annual fee 
	
	@Column(name="commission", nullable=false)
	 protected double commission;
	 // Junior broker has a commission equal to 2% of the total annual expected return of the portfolio.
	//Expert broker has a commission equal to 5% of the total annual expected return of the portfolio.

	protected Brokers() { super(); }

	/**
	 * @param code
	 * @param name
	 * @param address
	 * @param emails
	 */
	public Brokers(String code,String SEC, String name, Address address, String[] emails,int PersonID) {
		super(code, name, address, emails,PersonID);
		this.SEC=SEC;
		// TODO Auto-generated constructor stub
	}
	
	
	abstract public String getType();
	
	//********************************************
	//getters and setters
	
	public String getSEC() {
		return SEC;
	}
	
	public void setSEC(String sEC) {
		SEC = sEC;
	}
	
	public double getAnnualFee() {
		return annualFee;
	}
	
	public void setAnnualFee(double annualFee) {
		this.annualFee = annualFee;
	}
	
	public double getCommission() {
		return commission;
	}
	
	public void setCommission(double commission) {
		this.commission = commission;
	}

}
