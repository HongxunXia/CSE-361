package unl.cse.JPA2;
/**********
 * DataConverter.java
 * Bin Chen and Joshua Schmitz 
 * 27 September 2013
 * 
 * CSCE 156
 * Fall 2013
 * HW2
 * 
 * Resources: 	TAs & Instructor
 * 				http://stackoverflow.com/questions/3642820/xstream-correct-way-to-save-xml-in-utf-8
 * 				http://xstream.codehaus.org/manual-tweaking-output.html
 * 
 *********/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

import com.thoughtworks.xstream.XStream;
//import com.google.gson.Gson
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.PrintWriter;

@SuppressWarnings("unused")
public class DataConverter {
	
	public static void main(String[] args) {
		ArrayList<Person> personList = new ArrayList<Person>(Person.personParser().values());
		ArrayList<Assets> assetList = new ArrayList<Assets>(Assets.assetsParser().values());
		//Person.personParser() gives a Map from person code to the instance, .values() gives all the values in the range of the map,
		//then put them into the ArrayList<Person>

	//**************************************
		/*Using lib to convert object to JSON and write to a file, need to formatt the output to the way we want
	      Gson gson = new Gson();
	   String json = gson.toJson(personList);
	    
	   try {
			//write converted json data to a file named "file.json"
			FileWriter writer = new FileWriter("data/person11111.json");
			writer.write(json);
			writer.close();
	 
		} catch (IOException e) {
			e.printStackTrace();
		}
	   
	    System.out.println(json);*/
    //****************************************   
    	
    //using the class method "Person.tojson(int count,ArrayList<Person> personList,String file)" to output data to Json format
	Person.tojson(Person.personCount(), personList,"data/Person.json");

	//output Person.dat to xml
	XStream xstream = new XStream();
	try {
		xstream.toXML(personList, new FileOutputStream(new File("data/Person.xml")));
	} catch (FileNotFoundException e) {
		//Auto-generated catch block
		e.printStackTrace();
	}

    	//output Assets.dat to json
    	Assets.tojson(Assets.assetsCount(), assetList, "data/Assets.json");  //output serialized class data to JSON
    	
    	//output Assets.dat to xml
    	XStream xstream2 = new XStream(); //output serialized class data to XML
    	try {
			xstream2.toXML(Assets.assetsParser(), new FileOutputStream(new File("data/Assets.xml")));
		} catch (FileNotFoundException e) {
			//Auto-generated catch block
			e.printStackTrace();
		}
    
	}//end main
	
}
