package unl.cse.JPA2;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="Portfolio")
@SuppressWarnings("unused")
public class Portfolio {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PortfolioID", nullable=true)
	private int PortfolioID;
	

	@Column(name="portfolioCode", nullable=true)
	private String code;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BrokerID", nullable=false)
	private Brokers manager;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BeneficiaryID", nullable=false)
	private Person beneficiary ;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="OwnerID", nullable=true)
	private Person owner;
	
	@ManyToMany
	@JoinColumn(name="PortfolioID")
	
	
	
	

	@Transient
	private List<Assets> assetslist;
	
	private Portfolio(){
		this.code = null;
		this.owner = null;
		this.manager = null;
		this.beneficiary = null;
		this.assetslist = new  ArrayList<Assets>() ;
	}
	//********************************************
	//constructor
	/**
	 * @param code
	 * @param owner
	 * @param manager
	 * @param beneficiary
	 * @param assetslist
	 */
	public Portfolio(String code, Person owner, Brokers manager,
			Person beneficiary, ArrayList<Assets> assetslist) {
		super();
		this.code = code;
		this.owner = owner;
		this.manager = manager;
		this.beneficiary = beneficiary;
		this.assetslist = assetslist;
	}
	
	public Portfolio(int PortfolioID, String code, Person owner, Brokers manager,
			Person beneficiary, ArrayList<Assets> assetslist) {
		super();
		this.code = code;
		this.owner = owner;
		this.manager = manager;
		this.beneficiary = beneficiary;
		this.assetslist = assetslist;
		this.PortfolioID=PortfolioID;
	}
	
	
		
	//***********************************************************
	//getters and setters
	public String getCode() {
		return code;
	}
	
	public int getPortfolioID() {
		return PortfolioID;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public Brokers getManager() {
		return manager;
	}

	public void setManager(Brokers manager) {
		this.manager = manager;
	}
	
	public Person getBeneficiary() {
		return beneficiary;
	}
		
	public void setBeneficiary(Person beneficiary) {
		this.beneficiary = beneficiary;
	}

	public Person getOwner() {
		return owner;
	}
	
	public void setOwner(Person owner) {
		this.owner = owner;
	}
	
	public List<Assets> getAssetslist() {
		return assetslist;
	}
	
	public void setAssetslist(ArrayList<Assets> assetslist) {
		this.assetslist = assetslist;
	}
	
	public double getReturn(){
		double expReturn=0;
		if(this.assetslist==null){
			return 0;
		}
		for (int i=0;i<this.getAssetslist().size();i++){
			expReturn += this.getAssetslist().get(i).getAnnualReturn();
			}
		return expReturn;
	}
	
	public double getTotalValue(){
		if(this.assetslist==null){
			return 0;
		}
		double totalValue=0;
		for (int i=0;i<this.getAssetslist().size();i++){
			totalValue +=	this.getAssetslist().get(i).getValue();
			}
		return totalValue;	
	}
	
	public double getWeightedOmega(){
		if(this.assetslist==null){
			return 0;
		}
		double totalValue=0;
		double ov=0;
				for (int i=0;i<this.getAssetslist().size();i++){
				 totalValue +=	this.getAssetslist().get(i).getValue();
				 ov += this.getAssetslist().get(i).getRisk()*this.getAssetslist().get(i).getValue();
				}
				return ov/totalValue;		
	}
	
	public double getFees(){
		if(this.assetslist==null){
			return 0;
		}
		return this.assetslist.size()*this.manager.getAnnualFee();
	}
	
	public double getCommissions(){
		double commissions=this.getManager().commission*this.getReturn();
		return commissions;	
	}
	
	//***********************************************************
	//other methods

	//this method reads from Portfolio.dat file and create Porfolio instance then return an ArryList<Portfolio>.
	public static ArrayList<Portfolio> portfolioParser(){

		ArrayList<Portfolio> portfolioList = new ArrayList<Portfolio>();
		//create Person,Assets instances and maps 
		Map<String,Person> personMap = Person.personParser();
		Map<String,Assets> assetMap = Assets.assetsParser();
		//reading files from the "Portforlios.dat" file
				Scanner s=null;
				
					try {
						 s = new Scanner(new File("data/Portfolios.dat"));
					} catch (FileNotFoundException e) {
						//Auto-generated catch block
						e.printStackTrace();
					}
					
					String line;
					line=s.nextLine().replaceAll("\n", "");//read a line and get ride of "\n"
					int count=Integer.parseInt(line);// get total number of person in the data file
					
					while(s.hasNext()) {
						ArrayList<Assets> assetList = new ArrayList<Assets> ();
						line = s.nextLine();
						String tokens[] = line.split(";");
					
						String code = tokens[0];
						String owner=tokens[1];
						String manager = tokens[2];
						
						if (tokens.length==3){//no beneficiary, no assets
							String beneficiary=null;
							assetList=null;
							//create Portfolio instance
							Portfolio port= new Portfolio( code,  personMap.get(owner),(Brokers) personMap.get(manager),
									personMap.get(beneficiary), assetList);
							portfolioList.add(port);
						}
						else if (tokens.length==4){
							//has beneficiary, no assets
							String beneficiary=tokens[3];
							assetList=null;
							//create Portfolio instance
							Portfolio port= new Portfolio( code,  personMap.get(owner),(Brokers) personMap.get(manager),
									personMap.get(beneficiary), assetList);
							portfolioList.add(port);
						}
						else{
							String beneficiary=tokens[3];
							String assetsAll=tokens[4].trim();
							String token[]=assetsAll.split(",");
							for (String k: token){
								String oneAsset[]=k.split(":");
								//now map each asset code to correct instance
								//oneAsset[0] is the asset code, use assetMap to find the corresponding asset using the asset code
								if(assetMap.get(oneAsset[0]).getType().equals("D")){//Deposit 
									Deposit d = (Deposit) assetMap.get(oneAsset[0]).makeCopy();
									d.setTotalBalance(Double.parseDouble(oneAsset[1]));
									assetList.add(d);
								}
								else if (assetMap.get(oneAsset[0]).getType().equals("S")){//Stock
										Stocks stock = (Stocks) assetMap.get(oneAsset[0]).makeCopy();
										stock.setShareOwned(Double.parseDouble(oneAsset[1]));
										assetList.add(stock);
								}
								else if (assetMap.get(oneAsset[0]).getType().equals("P")){//Private Investment
									Private p=(Private) assetMap.get(oneAsset[0]).makeCopy();
									p.setPercentageOfStake(Double.parseDouble(oneAsset[1]));
									assetList.add(p);
								}
									
						}//end for each loop
							//create Portfolio instance
							Portfolio port= new Portfolio( code,  personMap.get(owner),(Brokers) personMap.get(manager),
									personMap.get(beneficiary), assetList);
							portfolioList.add(port);
							
						}
					
				}//end while
					return portfolioList;
		}//end portfolioParser()
	
	
	//******************************************
	//summary report method
	public static void summary(ArrayList<Portfolio> portfolioList){
		

		
		
//		Collections.sort( portfolioList, new Comparator<Portfolio>() {
//		 public int compare(Portfolio one, Portfolio other) {
//		    	if (one.getOwner().getLastName().equals(other.getOwner().getLastName())){
//		    		return one.getOwner().getFirstName().compareTo(other.getOwner().getFirstName());
//		    	}
//		    	else{
//		    		return one.getOwner().getLastName().compareTo(other.getOwner().getLastName());
//		    	}
//		        
//		    }
//	});
		
//		Collections.sort( portfolioList, new Comparator<Portfolio>() {
//			public int compare(Portfolio one, Portfolio other) {
//		    	if (one.getTotalValue()-other.getTotalValue()<0){
//		    		return 1;
//		    	}
//		    	else if (one.getTotalValue()-other.getTotalValue()>0){
//					return -1;
//				}
//		    	else{
//		    		return 0;
//		    	}
//		        
//		    }
//});
	
		
//		Collections.sort( portfolioList, new Comparator<Portfolio>() {
//			public int compare(Portfolio one, Portfolio other) {
//			if (one.getManager().getType()==other.getManager().getType()){
//				if (one.getManager().getLastName().equals(other.getManager().getLastName())){
//		    		return one.getManager().getFirstName().compareTo(other.getManager().getFirstName());
//		    	}
//		    	else{
//		    		return one.getManager().getLastName().compareTo(other.getManager().getLastName());
//		    	}
//		        
//		    }
//	    	else if (one.getManager().getType().equals("E")){
//				return -1;
//			}
//	    	else{
//	    		return 1;
//	    	}
//			}
//	        
//	    });
		
			
		
		
		
		
		
		     
		final String  HEADING_FMT_STR="%-12s %-18s %-20s %-12s %-12s %-20s %-15s %-15s\n";
		final String DATA_FMT_STR="%-12s %-18s %-20s $%-12.2f$%-12.2f%-20.4f $%-15.2f$%-15.2f\n";
		System.out.println("Portfolio Summary Report");
		System.out.println("===============================================================================================================================");
		System.out.printf(HEADING_FMT_STR,"Portfolio","Owner","Manager","Fees","Commissions","Weighted Risk","Return","Total");
		for (int i=0;i<portfolioList.size();i++){
			//System.out.println(i);//^^^^^^^^^^^^^^^^^^^^^^^^^
			String portfolioCode=portfolioList.get(i).getCode();
			String ownerName=portfolioList.get(i).getOwner().getName();
			String managerName=portfolioList.get(i).getManager().getName();
			double fees=portfolioList.get(i).getFees();
			double commissions=portfolioList.get(i).getCommissions();
			double weightedRisk=portfolioList.get(i).getWeightedOmega();
			double totalReturn=portfolioList.get(i).getReturn();
			double totalValue=portfolioList.get(i).getTotalValue();
			System.out.printf(DATA_FMT_STR,portfolioCode,ownerName,managerName,fees,commissions,weightedRisk,totalReturn,totalValue);			
		}//end for
		//show the total data
		System.out.println("                                                     __________________________________________________________________________");
		double feesTotal=0;
		double commissionsTotal=0;
		double returnTotal=0;
		double Totals=0;
				for (int i=0;i<portfolioList.size();i++){
					feesTotal+=portfolioList.get(i).getFees();
					commissionsTotal+=portfolioList.get(i).getCommissions();
					returnTotal+=portfolioList.get(i).getReturn();
					Totals+=portfolioList.get(i).getTotalValue();
				}
		System.out.printf("%40s %10s  $%-12.2f$%-12.2f%-20s $%-15.2f$%-15.2f\n\n\n\n"," ","Totals:",feesTotal,commissionsTotal," ",returnTotal,Totals);
		
	}//summary report method
	
	
	public static void summary(MySortedList<Portfolio> portfolioList){
		final String  HEADING_FMT_STR="%-12s %-18s %-20s %-12s %-12s %-20s %-15s %-15s\n";
		final String DATA_FMT_STR="%-12s %-18s %-20s $%-12.2f$%-12.2f%-20.4f $%-15.2f$%-15.2f\n";
		System.out.println("Portfolio Summary Report");
		System.out.println("===============================================================================================================================");
		System.out.printf(HEADING_FMT_STR,"Portfolio","Owner","Manager","Fees","Commissions","Weighted Risk","Return","Total");
		for (Portfolio p : portfolioList){
			//System.out.println(i);//^^^^^^^^^^^^^^^^^^^^^^^^^
			String portfolioCode=p.getCode();
			String ownerName=p.getOwner().getName();
			String managerName=p.getManager().getName();
			double fees=p.getFees();
			double commissions=p.getCommissions();
			double weightedRisk=p.getWeightedOmega();
			double totalReturn=p.getReturn();
			double totalValue=p.getTotalValue();
			System.out.printf(DATA_FMT_STR,portfolioCode,ownerName,managerName,fees,commissions,weightedRisk,totalReturn,totalValue);			
		}//end for
		//show the total data
		System.out.println("                                                     __________________________________________________________________________");
		double feesTotal=0;
		double commissionsTotal=0;
		double returnTotal=0;
		double Totals=0;
//				for (int i=0;i<portfolioList.size();i++){
//					feesTotal+=portfolioList.get(i).getFees();
//					commissionsTotal+=portfolioList.get(i).getCommissions();
//					returnTotal+=portfolioList.get(i).getReturn();
//					Totals+=portfolioList.get(i).getTotalValue();
//				}
				for (Portfolio p : portfolioList){
					feesTotal+=p.getFees();
					commissionsTotal+=p.getCommissions();
					returnTotal+=p.getReturn();
					Totals+=p.getTotalValue();
				}
		System.out.printf("%40s %10s  $%-12.2f$%-12.2f%-20s $%-15.2f$%-15.2f\n\n\n\n"," ","Totals:",feesTotal,commissionsTotal," ",returnTotal,Totals);
		
	}//summary report method
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Portfolio Details for one portfolio methods
	public  void details(){
		String beneficiary="";
		if (this.getBeneficiary()!=null){
			 beneficiary=this.getBeneficiary().getName();
		}
		System.out.println("Portfolio "+this.getCode());
		System.out.println("__________________________________________________________");
		System.out.println("Owner:          "+this.getOwner().getName());
		System.out.println("Manager:        "+this.getManager().getName());
		System.out.println("Beneficiary:    "+beneficiary);
		System.out.println("Assets");
		System.out.printf("%-12s %-38s %-12s %-14s %-20s %-7s\n","Code","Asset","Return Rate(%)","Risk (omega)","Annual Return","Value");
		if (this.assetslist!=null){
			for (int i=0;i<this.assetslist.size();i++){
				double returnRate=0;
				double risk=0;
				double annualReturn=0;
				double value=0;
				returnRate=this.assetslist.get(i).getReturnRate();
				risk=this.assetslist.get(i).getRisk();
				annualReturn=this.assetslist.get(i).getAnnualReturn();
				value=this.assetslist.get(i).getValue();
				System.out.printf("%-12s %-38s %-12.2f   %-12.2f   $%-18.2f  $%-7.2f\n",this.assetslist.get(i).assetCode,this.assetslist.get(i).getLabel()
						,returnRate,risk,annualReturn,value);
			}//end for
			System.out.println("                                                    _____________________________________________________________");
			//total them up		
			double annualReturnTotal=0;
			double valueTotal=0;
			for (int i=0;i<this.assetslist.size();i++){
			   
			    annualReturnTotal+=this.assetslist.get(i).getAnnualReturn();
			    valueTotal+=this.assetslist.get(i).getValue(); 
			}
			  System.out.printf("%53s %10s   %-12.4f   $%-20.2f$%-15.2f\n\n"," ","Totals:",this.getWeightedOmega(),annualReturnTotal,valueTotal);
		} 
		else{
			System.out.println("                                                    _____________________________________________________________");
			System.out.printf("%53s %10s $%-12.2f  $%-20.2f$%-15.2f\n\n"," ","Totals:",0.00,0.00,0.00);
		}			
	}//end details()
		
	////Portfolio Details for all portfolio methods
	public static void detailsAll(ArrayList<Portfolio> portfolioList){
		System.out.println("Portfolio Details");
		System.out.println("===============================================================================================================================");
		for (int i=0;i<portfolioList.size();i++){
			portfolioList.get(i).details();
		}	
	}
	
	
	
	
	
	
	
	

		
		
		
		
	
	
	
}//end class
