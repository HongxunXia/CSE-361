package unl.cse.JPA2;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity(name="Expert")
@DiscriminatorValue("E")
public class Expert extends Brokers {
	
	private Expert() { super(); }
//****************************************************
	//constructor
	/**
	 * @param code
	 * @param SEC
	 * @param name
	 * @param address
	 * @param emails
	 */
	public Expert(String code, String SEC, String name, Address address,
			String[] emails,int PersonID) {
		super(code, SEC, name, address, emails,PersonID);
		this.annualFee=10;
		this.commission=0.05;
		
	}

	@Override
	public String getType() {
		return "E";
	}

}
