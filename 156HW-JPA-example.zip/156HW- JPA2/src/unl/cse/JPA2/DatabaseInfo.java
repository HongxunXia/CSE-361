package unl.cse.JPA2;

public class DatabaseInfo {

	public static final String url = "jdbc:mysql://cse.unl.edu/jschmit";
	public static final String username = "jschmit";
	public static final String password = "3A64gm";
	
//	public static final String url = "jdbc:mysql://cse.unl.edu/bchen";
//	public static final String username = "bchen";
//	public static final String password = "hpM7r7";
}
