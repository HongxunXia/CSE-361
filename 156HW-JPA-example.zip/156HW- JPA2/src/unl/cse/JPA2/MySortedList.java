package unl.cse.JPA2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;





public class MySortedList<T> implements Iterable<T> {

	private Node<T> head = null;
	private Comparator<T> comp =null;

	public MySortedList (Comparator<T> comp){
		this.comp=comp;
	}
	
   public void removeAll(){
	   head=null;
   }

	private void addElementToHead(T item) {
		Node<T> newHead = new Node<T>(item);
		newHead.setNext(this.head);
		this.head = newHead;
	}
	
	
	
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^	
	public void addElement(T item){
		if(head == null){//then add to the head
			this.addElementToHead(item);
			return;
		}
		else {
			
			Node<T> current = head;
			Node<T> prev = null;
			Node<T> waitting=new Node<T>(item);
//			for(int i=0; i<this.getSize(); i++) {
//				if (this.comp.compare(current.getItem(), item)<0){
//					insertAtIndex(item,i);
//					return;
//				}
//				current = current.getNext();
//			}
			while (current != null && this.comp.compare(current.getItem(), item)<0){
				prev = current;
				current = current.getNext();
		
			}
			if (current == null ){
				//addint to the end
				prev.setNext(waitting);
				}
			else{
				if(prev!= null){
				prev.setNext(waitting);
				waitting.setNext(current);
				}
				else{
					addElementToHead(item);	
					
				}
			}
			
		
			
			
		}
	}
	
	
	
	public void addAll(ArrayList<T> list){
		for (T t: list){
			addElement(t);
		}
	}
	
	
	
	
	
	
	
	public void removeFirstInstanceOf(T item) {
		if(head == null) {
			return;
		} else if(head.getItem().equals(item)) {
			head = head.getNext();
		} else {
			Node<T> curr = head;
			Node<T> prev = null;
			
			while(curr.hasNext() && !curr.getItem().equals(item)) {
				prev = curr;
				curr = curr.getNext();
			}
			if(curr.getItem().equals(item))
				prev.setNext(curr.getNext());
		}
	}


//	private void insertAtIndex(T item, int index) {
//
//		if(index < 0 || index > this.getSize()) {
//			throw new IllegalArgumentException("index out of bounds");
//		}
//		
//		if(index == this.getSize()) {
//			addElementToEndOfList(item);
//			return;
//		} else if(index == 0) {
//			this.addElementToHead(item);
//			return;
//		}
//		
//		//find the node with index, index-1
//		Node<T> theNode = this.getNodeAtIndex(index-1);
//		Node<T> newNode = new Node<T>(item);
//		newNode.setNext(theNode.getNext());
//		theNode.setNext(newNode);
//		
//	}
	
//	public void addElementToEndOfList(T item) {
//    	if (this.head==null){//this list is empty
//    		addElementToHead(item);
//    	}
//    	else{
//    		
//    		Node<T> temp=this.head;//make temp point to the head
//        	Node<T> waitting=new Node<T>(item);
//    		
//    	
//    		while (temp.getNext()!=null){
//    			temp=(temp.getNext());
//    			
//    		}
//    		//now the temp is the last one
//    		temp.setNext(waitting);
//    		
//    	}
//	}	
	
	
	
	
	private Node<T> getNodeAtIndex(int index) {
		
		if(index < 0 || index >= this.getSize()) {
			throw new IllegalArgumentException("index out of bounds");
		}
		Node<T> current = head;
		for(int i=0; i<index; i++) {
			current = current.getNext();
		}
		return current;

	}
	
	@SuppressWarnings("unused")
	private T getElementAtIndex(int index) {

		Node<T> theNode = this.getNodeAtIndex(index);
		return theNode.getItem();
	}
	
	public int getSize() {
		Node<T> current = head;
		int counter = 0;
		while(current != null) {
			current = current.getNext();
			counter++;
		}
		return counter;
	}
	
	

	@Override
	public Iterator<T> iterator() {
		return new Iterator<T>() {
			Node<T> curr = head;
			@Override
			public boolean hasNext() {
				if(curr == null)
					return false;
				else
					return true;
			}
			@Override
			public T next() {
				T item = curr.getItem();
				curr = curr.getNext();
				return item;
			}

			@Override
			public void remove() {
				throw new UnsupportedOperationException("not implemented");
			}};
	}

	@Override
	public String toString() {
		if(this.head == null) {
			return "[empty]";
		}
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		Node<T> curr = head;
		while(curr.hasNext()) {
			sb.append(curr.getItem());
			sb.append(", ");
			curr = curr.getNext();
		}
		sb.append(curr.getItem());
		sb.append("]");
		return sb.toString();
	}

	  public void print() {
	    	Node<T> temp = this.head;
	    	while (temp!=null){
	    		System.out.println(temp.getItem().getClass());
	    		temp=(temp.getNext());
	    	}
	    }
	    
	

}
