package unl.cse.JPA2;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Transient;


@Entity(name="Deposit")
@DiscriminatorValue("D")
public class Deposit extends Assets {
	
	@Column(name="apr", nullable=false)
	private double apr;
	
	@Transient
	private double totalBalance;
	 
//********************************************
private Deposit(){super();}

	//constructor
	/**
	 * @param assetCode
	 * @param type
	 * @param label
	 */
	public Deposit(String assetCode, String type, String label,double apr) {
		super(assetCode, type, label);
		this.apr=apr;
		this.totalBalance=0.0;
	}
	
	/*Deposit Accounts have the following format:
		code;D;label;apr*/
	
//*********************************************
	//getters and setters

	public double getTotalBalance() {
		return totalBalance;
	}
	

	public void setTotalBalance(double totalBalance) {
		this.totalBalance = totalBalance;
	}

	public double getApr() {
		return apr;
	}

	@Override
	public Deposit makeCopy() {
		Deposit d= new Deposit(null,null,null,0);
		d.assetCode=this.assetCode;
		d.label=this.label;
		d.apr=this.apr;
		return d;
	}

	@Override
	public double getValue() {		
		return this.totalBalance;
	}

	@Override
	public double getAnnualReturn() {
		double annualReturn=(this.getReturnRate()/100)*this.totalBalance;
		//double roundedAnnualReturn=Math.round(annualReturn*100)/100.0;
		return annualReturn;
	}

	@Override
	public double getRisk() {		
		return 0;
	}

	@Override
	public double getReturnRate() {
		double APY=(Math.pow(Math.E, this.apr/100.0)-1)*100;
		//double roundedAPY=Math.round(APY*100)/100.0;
		return APY;
	}

	@Override
	public String getType() {
		return "D";
	}
	
	
	
	
//	//=============for JPA==================
//	@Override
//	public String getTypeJPA() {
//		return "D";
//	}
//	@Override
//	public Assets makeCopyJPA() {
//		Deposit d= new Deposit(null,null,null,0);
//		d.assetCode=this.assetCode;
//		d.label=this.label;
//		d.apr=this.apr;
//		return d;
//	}
//	@Override
//	public double getValueJPA() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//	@Override
//	public double getAnnualReturnJPA() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//	@Override
//	public double getRiskJPA() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//	@Override
//	public double getReturnRateJPA() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
	
	
	


}
