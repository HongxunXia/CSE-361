
In Eclipse, you need to ensure that your persistence.xml file 
is available for Hibernate.  The easiest way to do this is to
create your runnable JAR file and select the option "Extract Required
libraries into generated JAR file"
